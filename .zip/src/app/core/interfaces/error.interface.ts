export interface IError {
  title: string;
  message: string;
}
