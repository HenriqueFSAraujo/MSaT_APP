import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
// import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
// import { HttpUrlEncodingCodec } from '@app/auth-interceptor';

// import { environment } from '@env/environment';
// import { User } from '@shared/models/user-model';
// import { UserSearch } from '@shared/models/user-search-model';
// import { CustomErrorHandler } from './tools/custom-error-handler';
// import { UploadFileService } from '../components/upload-file/upload-file.service';
// import { Paging } from '@shared/models/paging-model';

// import * as moment from 'moment';
// import { Profile } from '../shared/models/profile-model';

@Injectable()
export class UserService {

  // private endpointUrl = environment.apiEndpoint + 'v1/users';  // URL to web API

  constructor(
    private http: HttpClient,
    private httpClient: HttpClient,
  ) {
      console.log('userservice');
  }

  // get(userId: string): Promise<User> {
  //   return this.http.get<User>(this.endpointUrl + '/User/' + userId)
  //     .toPromise()
  //     .then(data => { return data; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }

  // search(searchModel: UserSearch): Promise<Paging<User>> {
  //   let params = new HttpParams({ encoder: new HttpUrlEncodingCodec() });

  //   if (!String.isNullOrEmpty(searchModel.firstName)) {
  //     params = params.append('firstName', searchModel.firstName);
  //   }

  //   if (!String.isNullOrEmpty(searchModel.username)) {
  //     params = params.append('username', searchModel.username);
  //   }

  //   if (!String.isNullOrEmpty(searchModel.sort)) {
  //     params = params.append('sort', searchModel.sort.toString());
  //     params = params.append('sortDirection', searchModel.sortDirection.toString());
  //   }

  //   params = params.append('page', searchModel.page.toString());
  //   params = params.append('pageSize', searchModel.pageSize.toString());

  //   return this.http.get<Paging<User>>(this.endpointUrl, { params: params })
  //     .toPromise()
  //     .then(data => { return data; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }

  // getProfile(): Promise<Profile[]> {
  //   return this.http.get<Profile[]>(this.endpointUrl + '/profiles')
  //     .toPromise()
  //     .then(data => { return data; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }


  // add(user: User): Promise<boolean> {
  //   let body = user;

  //   return this.http.post(this.endpointUrl, body, { responseType: 'text' })
  //     .toPromise()
  //     .then(() => { return true; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }

  // update(userId: number, user: User): Promise<boolean> {
  //   let body = user;

  //   return this.http.put(this.endpointUrl + '/' + userId, body, { responseType: 'text' })
  //     .toPromise()
  //     .then(() => { return true; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }

  // updateAddress(userId: string, user: User): Promise<boolean> {
  //   let body = user;

  //   return this.http.put(this.endpointUrl + '/User/' + userId + '/Address', body, { responseType: 'text' })
  //     .toPromise()
  //     .then(() => { return true; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }

  // resetAccount(userId: string, email: string): Promise<boolean> {
  //   let body = { email: email };

  //   return this.http.put(this.endpointUrl + '/User/' + userId + '/Reset', body, { responseType: 'text' })
  //     .toPromise()
  //     .then(() => { return true; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }

  // delete(userId: number): Promise<boolean> {
  //   return this.http.delete(this.endpointUrl + '/' +   userId, { responseType: 'text' })
  //     .toPromise()
  //     .then(() => { return true; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }

  // updateDeviceToken(userId: string, token: string): Promise<boolean> {
  //   let body = {
  //     appleToken: token
  //   };

  //   return this.http.put(this.endpointUrl + '/User/' + userId + '/DeviceToken', body, { responseType: 'text' })
  //     .toPromise()
  //     .then(() => { return true; })
  //     .catch(CustomErrorHandler.handleApiError);
  // }


}
