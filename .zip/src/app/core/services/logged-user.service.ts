import { Inject, Injectable } from '@angular/core';
import { LoggedUser } from '@app/core/models/logged-user-model';
import { User } from '@app/core/models/user-model';

import { JwtService } from '@app/core/services/jtw.service';
import { AesService } from '@app/core/utils/aes.service';

@Injectable()
export class LoggedUserService {
  loggerUser!: LoggedUser;

  constructor(    
    @Inject(AesService) private aesService: AesService,
    private jwtService: JwtService) {
    this.loadUserData();
  }

  loadUserData() {
    this.readToken();
  }
  
  get isAdmin(): boolean {
    if (this.loggerUser === undefined || this.loggerUser === null) {
      return false;
    }
    return this.loggerUser.roles.filter((r: any) => r === 'ROLE_ADMIN').length > 0 ? true : false;
  }

  get isSuperAdmin(): boolean {
    if (this.loggerUser === undefined || this.loggerUser === null) {
      return false;
    }
    return this.loggerUser.roles.filter((r: any) => r === 'ROLE_SUPERADMIN').length > 0;
  }

  get isLogged(): boolean {
    return this?.loggerUser && this.loggerUser?.username && (this.loggerUser.username!=='') ? true : false;
  }

  public getUser(): User {
    let nameRole = ''
    nameRole = this.loggerUser.roles.filter((r: any) => r === 'ROLE_ADMIN').length > 0 ? 'Administrador' : nameRole;
    const user = {...this.loggedUser};
    return  {
      email: user.email,
      firstName:  user.firstName,
      fullname: user.firstName,
      lastName: user.lastName,      
      username: user.username,
      nameRole
    }    
  }

  get loggedUser(): LoggedUser {
    return this?.loggerUser;
  }

  private readToken(): void {
    const token: string = this.aesService.cookieGet('token') ? this.jwtService.decodeToken(this.aesService.decryptFromString(this.aesService.cookieGet('token'))) : undefined; 
    this.loggerUser = new LoggedUser(token);
  }
}
 