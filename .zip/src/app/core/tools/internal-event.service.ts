import { Inject, inject, Injectable } from '@angular/core';
import { Notification } from '@app/core/models/notification-model';
import { Subject, tap } from 'rxjs';
import { createEffect, explicitEffect } from '../utils/create-effect';
import { SidebarStore } from '@src/app/guarantees/profiles/admin/layouts/sidebar/sidebar.store';
import { LOGGED_USER_SERVICE_TOKEN, SIDE_BAR_PROFILE_ADMIN_STORE } from '@src/app/guarantees/shared/helpers/tokens/tokens';



@Injectable()
export class InternalEventService {
  private logOutSource = new Subject<string>();
  public logOut$ = this.logOutSource.asObservable();
  // private readonly itemStore = inject(SidebarStore);

  private logInSource = new Subject<string>();
  public logIn$ = this.logInSource.asObservable();

  private toggleThemeSource = new Subject<string>();
  public toggleTheme$ = this.toggleThemeSource.asObservable();

  private changePhotoSource = new Subject<string>();
  public changePhoto$ = this.changePhotoSource.asObservable();

  private updateNotificationsSource = new Subject<boolean>();
  public updateNotifications$ = this.updateNotificationsSource.asObservable();

  private applyNotificationSource = new Subject<Notification>();
  public applyNotification$ = this.applyNotificationSource.asObservable();

  private showNotificationSource = new Subject<boolean>();
  public showNotification$ = this.showNotificationSource.asObservable();

  private sidebarMenuOpen = new Subject<boolean>();
  public sidebarMenuOpen$ = this.sidebarMenuOpen.asObservable();

  // public InternalEventService(
  //   @Inject(SidebarStore) private sidebarStore: SidebarStore,
  // ){}

  loggedId(): void {
    this.logInSource.next('');
  }

  loggedOut(): void {
    this.logOutSource.next('');
  }

  toggleTheme(): void {
    let dark = localStorage.getItem('dark-theme') === 'Y';
    localStorage.setItem('dark-theme', dark ? 'N' : 'Y');

    this.toggleThemeSource.next('');
  }

  changePhoto(): void {
    this.changePhotoSource.next('');
  }

  updateNotifications(): void {
    this.updateNotificationsSource.next(true);
  }

  applyNotifications(notification: Notification): void {
    this.applyNotificationSource.next(notification);
  }

  showNotification(show: boolean) {
    this.showNotificationSource.next(show);
  }


}
