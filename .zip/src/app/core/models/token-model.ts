﻿export class Token {
  access_token: string = '';
  accessToken: string = '';
  refreshToken: string = '';
  token_type: string = '';
  expires_in: number = 0;
  refresh_token: string = '';
  token: string = '';
  
}
