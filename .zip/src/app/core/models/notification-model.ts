import { Paginator } from './paginator-model';

export class Notification {
  notificationId!: number;
  notificationTypeId!: number;
  dismissed!: boolean;
  referenceDate!: Date;
  notificationData!: string;
  creationDate!: Date;
  notificationType!: NotificationType;
}

export class NotificationType {
  notificationTypeId!: string;
  description!: string;
}

export class NotificationSearch extends Paginator {
  notificationId!: number;
  notificationTypeId!: string;
  notificationTypeIds!: number[];
  dismissed!: boolean;
}
