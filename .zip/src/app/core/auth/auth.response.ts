export interface AuthResponse {
    token: string;
    RefreshToken: string;
    
}
