import { Component, Inject, inject} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { DatetimeHelper } from '@app/core/helpers/datetime.helper';
import { CommonService } from '@app/core/services/common.service';
// import { AdminRoutes } from '@app/admin/admin.routes';
// import { AppRoutes } from 'src/app/app.routes';
import { pageTransition } from '@app/shared/utils/animations';
import { Images } from '@src/assets/data/images';
import { AlertType } from '@app/shared/components/alert/alert.type';
import { PublicRoutes } from '@app/public/public.routes';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { User } from '@app/core/models/user-model';
import { SigninStore } from './signin.store';
import { AesService } from '../../utils/aes.service';
import { AuthService } from '../auth.service';
import { AuthStore } from '../auth.store';
import { createEffect } from '../../utils/create-effect';
import { tap } from 'rxjs';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css'],
  animations: [pageTransition],
  providers: [ SigninStore, FormBuilder, AuthStore, AuthService ]
})
export class SigninComponent {
  protected readonly store = inject(SigninStore);
  protected readonly authStore = inject(AuthStore);
  protected readonly authService = inject(AuthService);
  readonly signinBannerImage: string = Images.bannerLogo;
  readonly publicRoutes = PublicRoutes;
  readonly currentYear: number = DatetimeHelper.currentYear;
  protected readonly AlertType = AlertType;

  user: User;
  title: string;
  email: string;
  formSubmited: boolean = false;
  form: UntypedFormGroup;
  serverErrors: string[] = [];

  signInForm = this.formBuilder.group({
    username: [''],
    password: [''],
    termsAccept: ['']
  });

  constructor(
    @Inject(Router) public router: Router,
    @Inject(FormBuilder) private formBuilder: FormBuilder,
    public commonService: CommonService
  ) {
    this.user = { username: '', password: '' };
    this.title = 'Login';
    this.email = '';
    this.form = this.createFormGroup();
    this.signInForm = this.createFormGroup();
  }

  public setUser(user_: User){
    createEffect<{ user: User }>(_ => _.pipe(tap(({ user }) => {
      user = user_;
      return this.authStore.$setUser.set(user);
    }))); 
  }

  public setLoading(isLoading: boolean){
    createEffect<{ loading: boolean }>(_ => _.pipe(tap(({ loading }) => {
      loading = isLoading;
      return this.store.$setLoading.set(loading);
    }))); 
  }

  protected onFormSubmitHandler = async (event: SubmitEvent) => {
    event.preventDefault();
    if (this.signInForm.valid) {
      const formModel = this.signInForm.value;
      let email: string = formModel.username as string;
      let password: string = formModel.password as string;
      this.store.setLoading({loading: true})
      setTimeout( async () => {
        
        try {        
          const response:any = await this.authService.login(email, password); 
          console.log('response ', response);
          if(response===401){
            this.store.setLoading({loading: false})
            // this.serverErrors = ['Acesso negado, credênciais incorretas!']
          } else {
            if (response){
              setTimeout( async() => await this.router.navigate([response], { queryParams: { },  queryParamsHandling: null, skipLocationChange: true}), 300);
            } else {
              setTimeout(() => {
                this.signInForm.controls.password.markAsDirty();
                this.signInForm.controls.username.markAsDirty();
                this.signInForm.controls.termsAccept.markAsDirty();
              }, 1);
            }
          }
          // this.store.setLoading({loading: false})
  
        } catch (error) {
          setTimeout(() => {
            this.signInForm.controls.password.markAsDirty();
            this.signInForm.controls.username.markAsDirty();
            this.signInForm.controls.termsAccept.markAsDirty();
            this.store.setLoading({loading: false})
          }, 1);
        }
      }, 1500);
        
      // this.authService.login(email, password).pipe(map((data:any)=>{
      //   let logged = this.extractData(data.object);
      //   if (logged) {
      //     this.loggedUserService.loadUserData();        
      //     this.internalEventService.loggedId();    
  
      //     const user = {...this.loggedUserService.loggedUser};
      //     return  {
      //       email: user.email,
      //       firstName:  user.firstName,
      //       fullname: user.firstName,
      //       lastName: user.lastName,
      //       roles: user.roles,
      //       username: user.username,
      //       urlRedirect: this.redirectProfile()
      //     }
      //   } else {
      //     return undefined;
      //   }   
           
      //  }));
      
      // .pipe(tap((user)=>{
      //   console.log('response user', user);
      //   if (user){
      //     this.router.navigateByUrl(response.urlRedirect);
      //   } else {
      //     setTimeout(() => {
      //       this.signInForm.controls.password.markAsDirty();
      //       this.signInForm.controls.username.markAsDirty();
      //       this.signInForm.controls.termsAccept.markAsDirty();
      //     }, 1);
      //   }

      // }))
      
      
      
    };
  }

  protected onAlertCloseHandler = (e: any) => {
    this.serverErrors = [];
  };

  private createFormGroup(): UntypedFormGroup {
    let group = new FormGroup({
      username: new FormControl(this.user.username, [Validators.required, Validators.minLength(5)]),
      password: new FormControl(this.user.password, [Validators.required, Validators.minLength(5)]),
      termsAccept: new FormControl(this.user.termsAccept, [Validators.required]),
    }, { updateOn: 'change' });
    return group;
  }

  ngOnInit(): void {
    this.title = 'Login';    
  }

}
