export interface Signin {
    username: string;
    password: string;
}