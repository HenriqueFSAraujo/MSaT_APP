export interface ResetPassword {
    email?: string;    
    password?: string;
    repeatPassword?: string;
    username?: string;
    fullname?: string;
    link?: string;

}
