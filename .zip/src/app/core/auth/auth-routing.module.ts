import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {PublicRoutes} from "@app/public/public.routes";
import {SignupComponent} from "./signup/signup.component";
import {SigninComponent} from "./signin/signin.component";
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

const routes: Routes = [
  {
    title: "Signin",
    path: PublicRoutes.Signup,
    component: SignupComponent
  },
  {
    title: "Acesso",
    path: PublicRoutes.Signin,
    component: SigninComponent
  },
  {
    title: "Esqueci a senha",
    path: PublicRoutes.forgotPass,
    component: ForgotPasswordComponent
  },
  {
    title: "Alterar senha",
    path: PublicRoutes.resetPass,
    component: ResetPasswordComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
