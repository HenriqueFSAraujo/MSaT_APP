import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AuthModule } from '@app/core/auth/auth.module';
import { HomeComponent } from '@app/public/home/home.component';
import { PublicFooterComponent } from '@app/public/layouts/footer/footer.component';
import { PublicHeaderComponent } from '@app/public/layouts/header/header.component';
import { PageNotFoundComponent } from '@app/public/page-not-found/page-not-found.component';
import { PublicRoutingModule } from '@app/public/public-routing.module';
import { PublicComponent } from '@app/public/public.component';
import { AesService } from '../core/utils/aes.service';
import { JwtService } from '../core/services/jtw.service';
import { LoggedUserService } from '../core/services/logged-user.service';
import { FormBuilder, FormGroup, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { AlertModule } from 'ng-devui';
import { InternalEventService } from '../core/tools/internal-event.service';

@NgModule({
  declarations: [PublicComponent, PageNotFoundComponent, HomeComponent],
  imports: [
    CommonModule,
    PublicRoutingModule,
    // AuthModule,
    
    PublicHeaderComponent,
    PublicFooterComponent,
    RouterOutlet,
  ],

  providers: [
    CommonModule,
    AesService,
    JwtService,
    LoggedUserService,
    // AuthGuard,
    InternalEventService,
    RouterLink, 
    // FormBuilder, 
    // FormGroup,
    // UntypedFormControl, UntypedFormGroup, Validators,
    AlertModule,
    PublicModule
  ],
})
export class PublicModule {}
