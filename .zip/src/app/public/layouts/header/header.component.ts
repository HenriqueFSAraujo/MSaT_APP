import { Component, Inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonService } from '@app/core/services/common.service';
// import { AdminRoutes } from 'src/app/admin/admin.routes';
import { AppRoutes } from 'src/app/app.routes';
import { Images } from 'src/assets/data/images';
import { PublicRoutes } from '../../public.routes';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common'; 
@Component({
  selector: 'public-header',
  standalone: true,
  imports: [RouterLink, CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class PublicHeaderComponent {
  public mainLogo: string = Images.mainLogo;
  public logoOne: string = Images.logo.logoOne;
  readonly publicRoutes = PublicRoutes;
  readonly appRoutes = AppRoutes;
  // readonly adminRoutes = AdminRoutes;
  
  constructor(public readonly commonService: CommonService, @Inject(Router) public router: Router) {}
  public getRoute(): any{
    // return false
    return this.router.url
  }
}
