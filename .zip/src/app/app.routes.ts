export enum AppRoutes{
    Admin = "admin",
    Profile = "profile",
}