import { ChangeDetectionStrategy, Component, inject, OnInit, TemplateRef } from '@angular/core';
import { NgIf } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DevUIModule, TableWidthConfig } from 'ng-devui';
//--
import { pageTransition } from '@app/shared/utils/animations';
// import { DataTableComponent } from '@app/guarantees/shared/components/data-table/data-table.component';
// import { dataTableOptions, tableWidthConfig, dataFilterOptions } from '@app/guarantees/profiles/admin/views/registrations/contracts/contracts.configurations';
//import { RegistrationsContractsDtService } from '@app/guarantees/shared/services/registrations-contracts-dt.service';
//import { RegistrationsContractsDtStore } from '@app/guarantees/shared/stores/registrations-contracts-dt.store';
// import { FilterTableComponent } from '@app/guarantees/shared/components/filter-table/filter-table.component';

@Component({
  selector: 'app-contracts-details-modal',
  templateUrl: './contract-details-modal.html',
  styleUrls: ['./contract-details-modal.scss'],
  standalone: true,
//   providers: [RegistrationsContractsDtStore, RegistrationsContractsDtService],
  imports: [NgIf, DevUIModule, FontAwesomeModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [pageTransition]
})
export class ContractAdminDetailsModalComponent implements OnInit {
//   protected readonly store = inject(RegistrationsContractsDtStore);
//   tableOptions: any;
//   filterOptions: any;
//   tableConfig?: TableWidthConfig[];

  
  ngOnInit(): void {
//     this.store.searchDataTable();
//     this.tableOptions = dataTableOptions;
//     this.filterOptions = dataFilterOptions;
//     this.tableConfig = tableWidthConfig;
  }
}
