import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { pageTransition } from '@src/app/shared/utils/animations';

@Component({
  selector: 'app-dashboard-profile-admin',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  animations: [pageTransition]
})
export class ProfileAdminDashboardComponent implements OnInit {
  eventDate: any = formatDate(new Date(), 'MMM dd, yyyy', 'en');

  ngOnInit(): void {
  
  }
}
