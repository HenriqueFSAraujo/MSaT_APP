import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {  DevUIModule, DFormControlRuleDirective } from 'ng-devui';
import { FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { faStackOverflow, faGithub, faMedium } from '@fortawesome/free-brands-svg-icons';
import { faSquare, faCheckSquare, faBars, faChevronDown } from '@fortawesome/free-solid-svg-icons';
import { TranslateModule } from '@ngx-translate/core';
import { I18nDatePipe, I18nModule } from 'ng-devui/i18n';
import { IconModule } from 'ng-devui/icon';
import { LazyLoadModule } from 'ng-devui/utils';
import { NumberTransModule } from 'ng-devui/number-translation';

import { ProfileAdminRoutingModule } from '@app/guarantees/profiles/admin/profile-admin-routing.module';
import { LayoutsModule } from '@app/guarantees/profiles/admin/layouts/layouts.module';
import { ProfileAdminComponent } from '@app/guarantees/profiles/admin/profile-admin.component';
import {  ProfileAdminDashboardComponent } from '@app/guarantees/profiles/admin/views/dashboard/dashboard.component';
// import { PipesModule } from '../../shared/pipes/pipes.module';
// import { PageNotFoundComponent } from '@src/app/public/page-not-found/page-not-found.component';
import { HeaderComponent } from "@app/guarantees/profiles/admin/layouts/header/header-admin.component";
import { SidebarComponent } from './layouts/sidebar/sidebar.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { ContractAdminDetailsModalComponent } from '@app/guarantees/profiles/admin/views/registrations/contracts/contract-details-modal/contract-details-modal.component';
// import { ContractsAdminComponent } from './views/registrations/contracts/contracts.component';
// import { RegistrationsContractsDtService } from '../../shared/services/registrations-contracts-dt.service';
// import { RegistrationsContractsDtStore } from '../../shared/stores/registrations-contracts-dt.store';

@NgModule({
  declarations: [
    ProfileAdminComponent,
    ProfileAdminDashboardComponent,  
     
    // PageNotFoundComponent,

    
  ],
  imports: [
    
    CommonModule,
    
    ProfileAdminRoutingModule,
    LayoutsModule,
    HeaderComponent,
    TranslateModule,
    // PipesModule,
    DevUIModule,
    I18nModule,
    IconModule,
    LazyLoadModule,
     NumberTransModule,
     SidebarComponent,
    TranslateModule.forRoot(),
    
],

providers: [
  SidebarComponent,
  FooterComponent,
  // RegistrationsContractsDtService,
  // RegistrationsContractsDtStore,
],

exports: [    
  I18nDatePipe,
  
  TranslateModule,
  // PipesModule,
]

})
export class ProfileAdminModule {
  constructor(library: FaIconLibrary) {
    library.addIcons(
      faSquare,
      faCheckSquare,
      faStackOverflow,
      faGithub,
      faMedium,
      faBars,
      faChevronDown
    );
  }

 }
