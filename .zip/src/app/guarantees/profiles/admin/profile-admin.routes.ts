export enum ProfileRoutes {
  Profile = 'profile',
  Admin = 'admin'
}

export enum ProfileAdminRoutes {
  Dashboard = 'dashboard',
  Contracts = 'contracts',
  Modal = 'modal'
}

export enum ProfileLocatorRoutes {
  Dashboard = 'dashboard',
}