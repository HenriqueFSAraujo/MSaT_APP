import { Injectable, inject, signal, Signal } from '@angular/core';
import { AppStore } from "@app/app.store";
import { concatMap, debounceTime, tap, timer } from "rxjs";
import { createEffect } from '@app/core/utils/create-effect';
import { HeaderStore } from '../header/header.store';

@Injectable({ providedIn: 'root' })
export class SidebarStore {
    // private readonly appStore = inject(AppStore);
    protected readonly headerStore = inject(HeaderStore);
    private readonly state = {
        $sidebarMenuOpen: signal<boolean>(false),
    } as const;

    public readonly $sidebarMenuOpen = this.state.$sidebarMenuOpen.asReadonly();
    // public readonly $sidebarMenuOpen = signal<boolean>(false);

    public readonly setSidebarMenuOpen = createEffect<{
        isOpen: boolean
      }>(_ => _.pipe(
        debounceTime(200),
        tap(({ isOpen }) => { 
              
                 
            console.log('SidebarStore', isOpen);
            const sidebar: any = document.querySelector('.sidebar');
            sidebar.setAttribute('aria-expanded', isOpen ? 'true' : 'false');    
            this.state.$sidebarMenuOpen.set(isOpen);   
        })
      ));

    // public readonly $setSidebarMenuOpen = signal<boolean>(false);

    // public readonly setSidebarMenuOpen = createEffect<{sidebarMenuOpen: boolean}>(_ => _
    //     .pipe(tap(({ sidebarMenuOpen }) => {
    //         console.log('sidebarMenuOpen', sidebarMenuOpen);
            
    //         this.appStore.setSidebarMenuOpen({ sidebarMenuOpen })
    //     }))
    // );

    // public readonly toggleButtonMenu = createEffect<{        
    //     sidebarMenuOpen: boolean
    // }>(_ => _.pipe(
    //     tap(({ sidebarMenuOpen }) => {
    //         const sidebar = document.querySelector('.sidebar');
    //         sidebar?.setAttribute('aria-expanded', 'false');
    //         this.appStore.setSidebarMenuOpen({ sidebarMenuOpen });
    //     })
    // ));


}