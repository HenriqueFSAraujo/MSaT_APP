import { Directive, ElementRef, HostListener, inject } from '@angular/core';
import { SidebarStore } from './sidebar.store';

@Directive({
  selector: '[sidebarCollapse]',
  standalone: true,
})
export class SidebarCollapseDirective {
  protected readonly store = inject(SidebarStore);
  constructor(private elementRef: ElementRef) { }

  @HostListener('click') onClick() {
    console.log('HostListener');
    
    const elem = this.elementRef.nativeElement as HTMLElement;
    const sidebar = elem.closest('.sidebar');
    const sidebarIsCollapsed = sidebar?.getAttribute('aria-expanded');
    // this.store.setSidebarMenuOpen({isOpen: true})

    if (sidebarIsCollapsed === 'false') {
      elem.closest('.sidebar')?.setAttribute('aria-expanded', 'true');
    }
    else {
      sidebar?.setAttribute('aria-expanded', 'false');
    }

    const subMenu = sidebar?.querySelectorAll('.sub-menu');

    subMenu?.forEach((subMenu: Element) => {
      if (subMenu.getAttribute('aria-expanded') == 'true')
        subMenu.setAttribute('aria-expanded', 'false');

      subMenu.toggleAttribute('icon-hidden');
    });

  }
}
