import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  inject,
  OnDestroy,
  OnInit,
  Output,
  ViewEncapsulation
} from '@angular/core';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { CommonService } from '@app/core/services/common.service';
import { AppRoutes } from '@app/app.routes';
import { Images } from '@src/assets/data/images';
import { AuthService } from '@app/core/auth/auth.service';
import { SidebarStore } from './sidebar.store';
import { ProfileAdminRoutes, ProfileRoutes } from '../../profile-admin.routes';
import { CommonModule, NgIf } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DevUIModule } from 'ng-devui';
import { SidebarCollapseDirective } from './sidebar-collapse.directive';
import { HeaderStore } from '../header/header.store';


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  standalone: true,
  providers: [SidebarStore, CommonModule, RouterLink],
  imports: [NgIf, DevUIModule, FontAwesomeModule, CommonModule, RouterLink, SidebarCollapseDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})

export class SidebarComponent implements OnInit, AfterViewInit, OnDestroy {
  protected readonly store = inject(SidebarStore);
  protected readonly headerStore = inject(HeaderStore);
  sidebarIsCollapsed: boolean = true;
  public logoOne: string = Images.logo.logoOne;
  readonly appRoutes = AppRoutes;
  readonly profileRoutes = ProfileRoutes;
  readonly profileAdminRoutes = ProfileAdminRoutes;

  private routerSubscription: Subscription = new Subscription();

  @Output() sidebarCollapsed = new EventEmitter<boolean>();

  constructor(
    public readonly commonServices: CommonService,
    private readonly elementRef: ElementRef,
    private authService: AuthService,
    private router: Router) { 

    }

  ngOnInit(): void {
    

  }

  ngAfterViewInit(): void {
    this.subMenuToggleHandlerOnRouteChange();
    setTimeout(() => { this.subMenuToggleHandlerOnPageReload() }, 1);
  }

  ngOnDestroy(): void {
    this.routerSubscription.unsubscribe();
  }

  subMenuToggleHandler = (event: MouseEvent): void => {
    console.log('subMenuToggleHandler');
    const elem = event.target as HTMLElement;
    const subMenu = elem.closest("a.sub-menu") as Element;

    if (subMenu.getAttribute('aria-expanded') == 'false'){
      subMenu.setAttribute('aria-expanded', 'true');
      this.store.setSidebarMenuOpen({isOpen: true});
    }else{
      subMenu.setAttribute('aria-expanded', 'false');      
      this.store.setSidebarMenuOpen({isOpen: false});    
    }
  }

  subMenuToggleHandlerOnPageReload = (): void => {
    if(this.elementRef.nativeElement.querySelector('[aria-current="page"]')){
      const elem = this.elementRef.nativeElement.querySelector('[aria-current="page"]')
        .closest('ul.sub-menu-item') as Element;
      const subMenu = elem?.previousSibling as Element;
      subMenu?.setAttribute('aria-expanded', 'true');
    }
  }

  subMenuToggleHandlerOnRouteChange = (): void => {
    this.routerSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const subMenu = this.elementRef.nativeElement.querySelectorAll(".sub-menu");
        const elem = this.elementRef.nativeElement.querySelector(`[href='${event.url}']`) as Element;
        if (elem && elem.closest('ul.sub-menu-item')) return;
        subMenu.forEach((subMenu: Element) => {
          if (subMenu.getAttribute('aria-expanded') == 'true')
            subMenu.setAttribute('aria-expanded', 'false');
        });
      }
    })
  }

  onClickLogout = () => {
    this.authService.logout()
  };

  toggleButtonMenu(){    
    let isOpen = false;
    
    
    this.store.setSidebarMenuOpen({isOpen});    
    this.headerStore.setSidebarMenuOpen({isOpen});   
    
    // const sidebar: any = document.querySelector('.sidebar');
    // sidebar.setAttribute('aria-expanded', isOpen ? 'false' : 'false');  
    
  }

  // applySidebarMenuOpen(isOpen: boolean) {
  //   const itemStore = inject(SIDE_BAR_PROFILE_ADMIN_STORE);
  //   itemStore.setSidebarMenuOpen({isOpen})
  // }
}
