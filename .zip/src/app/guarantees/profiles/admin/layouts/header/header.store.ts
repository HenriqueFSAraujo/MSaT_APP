import { signal, Injectable, inject } from '@angular/core';
import { AppStore } from "@app/app.store";
import { debounceTime, tap } from "rxjs";
import { createEffect } from '@app/core/utils/create-effect';
import { SidebarStore } from '../sidebar/sidebar.store';

@Injectable({ providedIn: 'root' })
export class HeaderStore {
    // private readonly appStore = inject(AppStore);
    // protected readonly sideBarStore = inject(SidebarStore);

    private readonly state = {
        $user: signal<boolean>(false),
        // $user: this.appStore.$user,
        $sidebarMenuOpen: signal<boolean>(true)
        // $loadingUser: signal<boolean>(false)
    } as const;

    public readonly $user = this.state.$user;
    public readonly $sidebarMenuOpen = this.state.$sidebarMenuOpen;

    // public readonly $loading = this.state.$loadingUser.asReadonly();

    // public readonly toggleButtonMenu = createEffect<{        
    //     sidebarMenuOpen: boolean
    // }>(_ => _.pipe(
    //     tap(({ sidebarMenuOpen }) => {
    //         const sidebar = document.querySelector('.sidebar');
    //         sidebar?.setAttribute('aria-expanded', 'true');
    //         this.appStore.setSidebarMenuOpen({ sidebarMenuOpen });
    //     })
    // ));

    public readonly setSidebarMenuOpen = createEffect<{
        isOpen: boolean
      }>(_ => _.pipe(
        debounceTime(200),
        tap(({ isOpen }) => {            
          
            console.log('HeaderStore', isOpen);
            const menuHeader: any = document.querySelector('.menu-header');            
            menuHeader.setAttribute('aria-expanded', isOpen ? 'false' : 'true'); 
            this.state.$sidebarMenuOpen.set(isOpen);    
        })
      ));
    // setSidebarMenuOpen(isOpen: boolean) {
    //     this.state.$sidebarMenuOpen.set(isOpen);
    //   }
}