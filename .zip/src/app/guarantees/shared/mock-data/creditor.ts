  
  export const  creditorOptions = [
    {
      name: 'Banco do Brasil',
      value: 1,
    },
    {
      name: 'Caixa Econômica Federal',
      value: 2,
    },
    {
      name: 'Banco Bradesco',
      value: 3,
    },
    {
      name:  'Banco Itaú',
      value: 4,
    },
    {
      name: 'Banco Santander',
      value: 5,
    },
  
  ];

  
  
