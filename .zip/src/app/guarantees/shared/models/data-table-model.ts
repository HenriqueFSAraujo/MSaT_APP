export interface DataTableModel {
   id: number;
   checked: boolean;
   creditor: string;
   orderCreatedAt: Date;
   contractNum: string;
   carPlate: string;
   carModel: string;
   currentStage: string;
   seizureStatus: string;
   lastMoveUpdatedAt: Date;
}

