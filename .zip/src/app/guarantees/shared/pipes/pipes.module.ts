import { NgModule } from '@angular/core';
import { LocalizedDatePipe } from './LocalizedDatePipe';


const PIPES = [
    LocalizedDatePipe
];

@NgModule({
    imports: [],
    declarations: [...PIPES],
    providers: [],
    exports: [...PIPES]
})
export class PipesModule {
}