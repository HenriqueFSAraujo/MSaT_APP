import { NgIf } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DevUIModule} from 'ng-devui';

@Component({
  selector: 'm-dropdown-menu',
  templateUrl: './dropdown-menu.component.html',
  styleUrls: ['./dropdown-menu.component.scss'],
  standalone: true,
  imports: [NgIf, DevUIModule, FontAwesomeModule],
})
export class DropDownMenuComponent {
  @ViewChild('origin', { static: true })
    originRef!: ElementRef;

  onToggle(event:any) {
    console.log(event);
  }
}
