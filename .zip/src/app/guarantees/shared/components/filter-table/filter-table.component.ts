import { NgFor, NgIf } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, OnInit, TemplateRef, Input, ElementRef, Renderer2, ChangeDetectorRef, Inject, Output, EventEmitter, ViewChild } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { pageTransition } from '@src/app/shared/utils/animations';
import { DevUIModule, TableWidthConfig, } from 'ng-devui';
import { DCommonModule, } from 'ng-devui/common';
import { wipeInOutAnimation, fadeInOut } from 'ng-devui/utils';
import { MCommonsService } from '../../services/m-commons.service';
import { creditorOptions } from '../../mock-data/creditor';
import { of } from 'rxjs';
import { FormLayout } from 'ng-devui/form';
import { DFormControlRuleDirective } from 'ng-devui/form';
@Component({
  selector: 'app-filter-table',
  templateUrl: './filter-table.component.html',
  styleUrls: ['./filter-table.component.scss'],
  standalone: true,
  
  providers: [MCommonsService, ],
  imports: [NgIf, NgFor, DevUIModule, FontAwesomeModule, DCommonModule, ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [pageTransition, wipeInOutAnimation, fadeInOut]
})
export class FilterTableComponent implements OnInit {
  @Input()
  dataFilterOptions: any = { fields: [{ field: 'checkbox' }] };

  @Input() startDateModel: Date = new Date();
  @Output() startDateEvent = new EventEmitter<Date>();

  @Input() endDateModel: Date = new Date();
  @Output() endDateEvent = new EventEmitter<Date>();

  @Input() protocolModel: string = '';
  @Output() protocolEvent = new EventEmitter<string>();
  @ViewChild('myInputValidate') myInputValidate: DFormControlRuleDirective | any;

  @Input() creditorOptions: any = creditorOptions;
  @Input() creditorModel: any = { name: '', value: 0 };
  @Output() creditorEvent = new EventEmitter<any>();

  // updateRules() {
  //   this.myInputValidate.updateRules([
  //     { required: true },
  //     { minlength: 2 },
  //     { maxlength: 6 },
  //   ]);
  // }
  formData = {
    protocol: '',
    inputValue: '',
    textareaValue: '',
    radioValue: {},
    toggleValue: false,
    singDateValue: '',
    multiDateValue: {
      startDate: '',
      endDate: ''
    },
  };
  msgs: Array<Object> = [];

  layoutDirection: FormLayout = FormLayout.Horizontal;
  today = new Date();
  max = new Date(this.today.setDate(this.today.getDate() + 1));

  filterParams: any = {
    startDate: null,
    endDate: null,
    protocol: null,
    creditor: null,
  }


  // formRules: { [key: string]: DValidateRules } = {
  //   rule: { message: 'The form verification failed, please check.', messageShowType: 'text' },
  //   protocolRules: {
  //     validators: [
  //       { required: true },
  //       { minlength: 3 },
  //       { maxlength: 10 },
  //       {
  //         pattern: /^[a-zA-Z0-9]+(\s+[a-zA-Z0-9]+)*$/,
  //         message: 'The user name cannot contain characters except uppercase and lowercase letters.',
  //       },
  //     ],
  //     asyncValidators: [{ sameName: this.checkName.bind(this), message: 'Duplicate name.' }],
  //   },
 
  // };

  filterOptions: any;
  tableConfig?: TableWidthConfig[];
  open = false;

  constructor(private commonsService: MCommonsService) {
    this.commonsService.on<Date>('startDateEvent').subscribe(val => this.filterParams.startDate = val);
    this.commonsService.on<Date>('endDateEvent').subscribe(val => this.filterParams.endDate = val);
    this.commonsService.on<any>('protocolEvent').subscribe(val => this.filterParams.protocol = val);
    this.commonsService.on<any>('creditorEvent').subscribe(val => this.filterParams.creditor = val);
  }

  ngOnInit(): void {
    this.open = true
    // this.store.searchDataTable();
    this.filterOptions = this.dataFilterOptions;
    // this.tableConfig = tableWidthConfig;
  }

  onChangeProtocol(value: any) {
    this.protocolModel = value;
    this.commonsService.broadcast('protocolEvent', this.protocolModel);
    console.log('value ', value);
    console.log('filterParams ', this.filterParams);
  }

  onChangeCreditor(value: any) {
    if(value){
      
      this.creditorModel = JSON.parse(JSON.stringify(value));
      this.commonsService.broadcast('creditorEvent', JSON.parse(JSON.stringify(value)));
      console.log('value ', value);
      console.log('filterParams ', this.filterParams);
    }
  }

  onSelectObject = (term: any) => {
    return of(
      this.creditorOptions
        .map((option: any, index: number) => ({ id: index, option: option }))
        .filter((item: any) => item.option.name.toLowerCase().indexOf(term.toLowerCase()) !== -1)
    );
  };

  getDateEndValue(value: any) {
    this.commonsService.broadcast('endDateEvent', JSON.parse(JSON.stringify(value.selectedDate)));
    console.log('filterParams ', this.filterParams);
  }
  getDateStartValue(value: any) {
    // this.datePickerStart.setI18nText(
    // this.startDateEvent.emit(value);
    this.commonsService.broadcast('startDateEvent', JSON.parse(JSON.stringify(value.selectedDate)));
    console.log('filterParams ', this.filterParams);
  }



}
