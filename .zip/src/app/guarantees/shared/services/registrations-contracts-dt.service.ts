import { inject, Inject, Injectable } from '@angular/core';
// import { HttpClient } from "@angular/common/http";
// import { AesService } from '@app/core/utils/aes.service';
// import { AppStore } from '@app/app.store';
// import { RegistrationsContractsDtModel } from '../models/registrations-contracts-dt.model';

@Injectable()
export class RegistrationsContractsDtService {
    // public dataTable?: RegistrationsContractsDtModel;
    private endpoints: any = { search: `/guarantees/consultation` };

    constructor(
        // @Inject(AesService) private aesService: AesService, 
        // private httpClient: HttpClient
    ) { }

    searchData(): any {
        const data: any = [];
        

        for (let index = 0; index < 50; index++) {
            data.push(
                {
                    $halfChecked: false,
                    $checked: false,
                    
                    creditor: 'Santander',
                    orderCreatedAt: new Date(),
                    contractNum: '0000' + index + 1,
                    carPlate: 'GRO-6543',
                    carModel: 'Honda Fit',
                    currentStage: 'Busca pelo veículo',
                    seizureStatus: 'Localizador acionado',
                    lastMoveUpdatedAt: new Date(),

                    checked: false,
                    
                    
                    
                    

                    id: index + 1
                }
            );

        }

        return data;
    }

}
