import {ChangeDetectorRef, inject, Inject, Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {map, Observable, of} from "rxjs";
import { AesService } from '@app/core/utils/aes.service';
// import { Token } from '@app/shared/models/token-model';
// import { JwtService } from '@app/shared/services/jtw.service';
// import { LoggedUserService } from '@app/_core/services/logged-user.service';
// import { InternalEventService } from '@app/_core/tools/internal-event.service';
import { environment } from '@env/environment';
// import { User } from '@app/shared/models/user-model';
import { ActivatedRouteSnapshot, NavigationExtras } from '@angular/router';
import { Router} from '@angular/router';
// import { LoggedUser } from '@app/shared/models/logged-user-model';
import { AppStore } from '@app/app.store';
import { DataTableModel } from '../models/data-table-model';
import { DatePipe } from '@angular/common';
import { LOCALE_ID } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { TranslatePipe } from '../pipes/translate.pipe';

@Injectable()
export class DataTableService {
  // private readonly appStore = inject(AppStore);
  date = new Date(2014, 1, 11, 13, 1, 22);
  date1 = new Date(2015, 4, 5);
  public dataTable?: DataTableModel;

  private endpoints: any = {
    search: `/guarantees/consultation`,
  };

  constructor(
    @Inject(AesService) private aesService: AesService,
    private httpClient: HttpClient,    
    translate: TranslateService

  ) { 
    
    
    
  }
  searchData(): any {
    const data: any = [];
    const row = {
      
        isChecked: true,
        checked: true,
      creditor: 'Santander',
      orderCreatedAt: new Date(),
      contractNum: '12345678',
      carPlate: 'GRO-6543',
      carModel: 'Honda Fit',
      currentStage: 'Busca pelo veículo',
      seizureStatus: 'Localizador acionado',
      lastMoveUpdatedAt: new Date(),  
    }
    data.push(row);
    data.push(row);
    data.push(row);
    data.push(row);
    data.push(row);
    data.push(row);
      
    return data; 
  }

}
