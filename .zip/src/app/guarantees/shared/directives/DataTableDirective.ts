import { Directive, TemplateRef } from "@angular/core";

@Directive({
    selector: '[appDataTableContent]',
  })
  export class AppDataTableContentDirective {
    constructor(public templateRef: TemplateRef<unknown>) {}
  }