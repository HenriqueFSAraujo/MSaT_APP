export interface NgwTabContents {
    Title: string;
    IsActive?: boolean;
    IsDisabled?: boolean;
    TabTitle?: string;
    Contents: string;
}
