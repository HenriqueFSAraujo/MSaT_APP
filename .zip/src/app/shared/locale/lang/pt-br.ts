export default {
  pagination: {
    totalItemText: 'Total',
    goToText: 'Ir para',
  },
  accordion: {
    loading: 'carregando',
    noData: 'Sem dados',
  },
  autoCompleteDropdown: {
    latestInput: 'Última entrada',
  },
  cascaderList: {
    noData: 'Sem dados',
  },
  colorPicker: {
    foundationPanel: 'Paleta Básica',
    advancedPanel: 'Paleta Avançada',
  },
  datePickerPro: {
    ok: 'Aplicar',
    placeholder: 'selecione a data',
    month1: 'Jan',
    month2: 'Fev',
    month3: 'Mar',
    month4: 'Abr',
    month5: 'Mai',
    month6: 'Jun',
    month7: 'Jul',
    month8: 'Ago',
    month9: 'Set',
    month10: 'Out',
    month11: 'Nov',
    month12: 'Dez',
    year: 'Ano',
    startPlaceholder: 'selecione a data inicial',
    endPlaceholder: 'selecione a data final',
    getWeekDays(): Array<string> {
      return ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    },
    getTimeArr(): Array<string> {
      return ['Hr', 'Min', 'Seg'];
    },
    getYearMonthStr(year: number, month: number): string {
      return `${year} - ${month}`;
    },
  },
  editableSelect: {
    noRelatedRecords: 'Nenhum registro relacionado encontrado',
    noData: 'Sem dados',
  },
  input: {
    placeholder: 'Por favor insira',
  },
  splitterBar: {
    collapse: 'Recolher',
    expand: 'Expandir',
  },
  stepsGuide: {
    previous: 'Voltar',
    continue: 'Avançar',
    ok: 'Entendi',
  },
  table: {
    selectAll: 'Selecionar tudo',
    ok: 'aplicar',
  },
  timePopup: {
    ok: 'Aplicar',
  },
  transfer: {
    unit: '',
    panelUnit: '',
    headerUnit: '',
    noData: 'Sem dados',
    placeholder: 'Insira as palavras-chave',
  },
  tree: {
    loading: 'Carregando',
    newNode: 'Novo nó',
    selectPlaceholder: 'Por favor selecione',
  },
  upload: {
    placeholder: 'selecione um arquivo',
    getExistSameNameFilesMsg(sameNames: string): string {
      return `Existe arquivos duplicados : "${sameNames}" `;
    },
    getAllFilesBeyondMaximalFileSizeMsg(maximalSize: number): string {
      return `Tamanho (MB): ${maximalSize}. O arquivo excede o tamanho máximo`;
    },
    getBeyondMaximalFileSizeMsg(filename: string, maximalSize: number): string {
      return `Maximum file size (MB): ${maximalSize}. Files whose size exceeds the maximum value: ${filename}`;
    },
    getNotAllowedFileTypeMsg(filename: string, scope: string): string {
      return `Files with unsupported types: ${filename}. Supported file types: ${scope}`;
    },
  },
  search: {
    placeholder: 'Enter a keyword',
  },
  select: {
    placeholder: 'Selecione',
    noDataText: 'Sem dados',
    noMatchText: 'Sem correspondência',
    loadingText: 'Carregando...',
  },
  tagInput: {
    maxTagsText: 'Maximum number reached: ',
  },
  modal: {
    type: {
      success: {
        text: 'Sucesso',
      },
      info: {
        text: 'Informação',
      },
      warning: {
        text: 'Aviso',
      },
      error: {
        text: 'Erro',
      },
    }
  },
  timeSelect: {
    placeholder: 'Please select time',
  },
};
