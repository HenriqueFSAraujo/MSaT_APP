

// import enUS from './lang/en-us';
import ptBR from './lang/pt-br';
export declare function deepAssign(...objects: Record<string, unknown>[]): Record<string, unknown>;

let lang = 'pt-BR';
let langMessages: any = {
  [lang]: ptBR
};

const Locale = {
  messages(): Record<string, unknown> {
    return langMessages[lang];
  },

  lang(): string {
    return lang;
  },

  use(newLang: string, newMessages?: Record<string, unknown>): void {
    lang = newLang;
    this.add({ [newLang]: newMessages });
  },

  add(newMessages = {}): void {
    langMessages = deepAssign(langMessages, newMessages);
  },
};

export { Locale };

export default {
  install(app: any): void {
    app.config.globalProperties.langMessages = Locale.messages();
  }
};
