import * as process from 'process';

export const environment = {
  // ...window['process'].env,
  // secretKey: process.env['secretKey'],
  production: true,
  secretKey: "YXdUU1pMTjQ4R3pCMExRUGRjMTd5VGF1Q1FoYWZ6N1U=",
  apiUrl: "http://localhost:4202/api/v1/",    
  siteUrl: "http://localhost:4202",
  apiEndpoint: "http://localhost:4202/api/v1/",    
  domainCookie: "localhost",
  secureCookie: false,
  pathCookie: "/",
};
