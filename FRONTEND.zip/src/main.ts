import './polyfills';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { ThemeServiceInit } from 'ng-devui/theme';
import { uiLightTheme, uiDarkTheme } from './ui-theme';
import { provideAnimations } from "@angular/platform-browser/animations";
ThemeServiceInit({ 'ui-light-theme': uiLightTheme, 'ui-dark-theme': uiDarkTheme }, 'ui-light-theme');

// platformBrowserDynamic().bootstrapModule(AppModule)
//   .catch(err => console.error(err));



platformBrowserDynamic().bootstrapModule(AppModule, {
  providers: [
    provideAnimations(),
    // provideAnimations()
]
}).then(ref => {
  // Ensure Angular destroys itself on hot reloads.
  let win:any = window;
  if (win["ngRef"]) {
    win['ngRef'].destroy();
  }
  win['ngRef'] = ref;

  // Otherwise, log the boot error
}).catch(err => console.error(err));