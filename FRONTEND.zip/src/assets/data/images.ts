export interface IUsers {
  userOne: string;
}
export interface ILogo {
  logoOne: string;
}
export interface IAuth {
  signup: string;
}
export class Images {
  public static readonly mainLogo: string = './assets/images/authpage/logo-small-msiav.svg';
  public static readonly bannerLogo: string = './assets/images/logo/car-hero-core.svg';

  public static readonly auth: IAuth = {
    signup: './assets/images/authpage/signup.jpg',
  };

  public static readonly users: IUsers = {
    userOne: './assets/images/authpage/profile-image.png',
  };
  public static readonly logo: ILogo = {
    logoOne: './assets/images/authpage/logo-msiav.svg',
  };
}
