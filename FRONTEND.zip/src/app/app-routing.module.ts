import {NgModule} from '@angular/core';
import {PreloadAllModules, RouterModule, Routes} from '@angular/router';
import {AppRoutes} from '@app/app.routes';
import {PageNotFoundComponent} from '@app/public/page-not-found/page-not-found.component';
import { PublicComponent } from '@app/public/public.component';
import { GuaranteesComponent } from '@app/guarantees/profiles/guarantees.component';
// import { AuthGuard } from '@app/core/services/auth-guard.service';

const routes: Routes = [
  {
    path: '',
    component: PublicComponent,
    loadChildren: () => import('./public/public.module').then((m) => m.PublicModule)
  },  
  {
    path: AppRoutes.Profile,
    // component: GuaranteesComponent,
    loadChildren: () => import('@app/guarantees/profiles/guarantees.module').then((m) => m.GuaranteesModule),    
  },
  {
    path: '**',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      // enableTracing: true, //uncomment for debugging only
    preloadingStrategy: PreloadAllModules,
    scrollPositionRestoration: 'top',
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
