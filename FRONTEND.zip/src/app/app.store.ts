import { computed, inject, Inject, Injectable, signal } from "@angular/core";
import { createEffect } from "@app/core/utils/create-effect";
import { tap } from "rxjs";
// import { User } from "./shared/models/user-model";
// import { LoadingService } from 'ng-devui/loading';
import { AppService } from "./app.service";

@Injectable({ providedIn: 'root' })
export class AppStore {
  private readonly state = {
    // $user: signal<User | undefined>(undefined),
    $loadingUser: signal<boolean>(false),
    $loadingGlobal: signal<boolean>(false),
    $loggedIn: signal<boolean>(false),
    $sidebarMenuOpen: signal<boolean>(true),
  } as const;

  resultTarget: any;
  isShow: boolean = false;
  // public readonly $user = this.state.$user.asReadonly();
  public readonly $loadingUser = this.state.$loadingUser.asReadonly();
  public readonly $loadingGlobal = this.state.$loadingGlobal.asReadonly();
  public readonly $loggedIn = this.state.$loggedIn.asReadonly();
  public readonly $sidebarMenuOpen = this.state.$sidebarMenuOpen.asReadonly();

  public readonly $loading = computed<boolean>(() => {
    const isLoading = this.$loadingUser() || this.$loadingUser() || this.$loadingGlobal() || this.$loggedIn();
    console.log('isLoading ', isLoading);
    return isLoading;
  });

  constructor(
    // private loadingService: LoadingService,
    @Inject(AppService) private appService: AppService,
  ) {
    this.appService.retrieveContractsData()
  }

  // public readonly $setUser = signal<User | undefined>(undefined);
  public readonly $setLoadingUser = signal<boolean>(false);
  public readonly $setLoadingGlobal = signal<boolean>(false);
  public readonly $setLoggedIn = signal<boolean>(false);
  public readonly $setSidebarMenuOpen = signal<boolean>(false);

  // openFullScreen() {
  //   const results = this.loadingService.open();
  //   return results;
  // }

  closeTargetLoading() {
    this.resultTarget.loadingInstance.close();
    this.isShow = false;
  }

  // public readonly setUser = createEffect<{
  //   user: User | undefined
  //   loadingUser: boolean
  // }>(_ => _.pipe(
  //   tap(({ user, loadingUser }) => {
  //     this.state.$user.set({ ...user, nameRole: 'Administrador'  });
  //     this.state.$loadingUser.set(loadingUser);
  //   })
  // ));

  // public readonly setSidebarMenuOpen = createEffect<{ sidebarMenuOpen: boolean }>
  //   (_ => _.pipe(tap(({ sidebarMenuOpen }) => this.state.$sidebarMenuOpen.set(sidebarMenuOpen))));

  // public readonly setLoadingGlobal = createEffect<{ loadingGlobal: boolean }>(_ => _.pipe(tap(({ loadingGlobal }) => {
  //   this.state.$loadingGlobal.set(loadingGlobal);
  //   if (this.$loading()) {
  //     this.resultTarget = this.openFullScreen();
  //   } else {
  //     this.resultTarget ? this.resultTarget.loadingInstance.close() : '';
  //     this.resultTarget = undefined;
  //   }
  // })));

  // public readonly setLoggedIn = createEffect<{ loggedIn: boolean }>(_ => _.pipe(tap(({ loggedIn }) => {
  //   this.state.$loggedIn.set(loggedIn);
  // })));
}
