import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClient, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { AppRoutingModule } from '@app/app-routing.module';
import { DevUIModule } from 'ng-devui';
import { AppComponent } from '@app/app.component';
import { PublicModule } from '@app/public/public.module';
import { httpInterceptorProviders } from '@app/core/interceptors/interceptors.provider';
import { StrategyProviders } from "@app/core/strategies/strategy.providers";
import { UtilsProviders } from "./shared/utils/utils.providers";
import { I18n } from "i18n-js";

async function loadTranslations(i18n: any, locale: any) {
  const response = await fetch(`/assets/i18n/pt-BR.json`);
  const translations = await response.json();
  i18n.store(translations);
}

import { FontAwesomeModule, FaIconLibrary, } from '@fortawesome/angular-fontawesome';
import { faSquare, faCheckSquare, faBars, faTimes } from '@fortawesome/free-solid-svg-icons';
import { faSquare as farSquare, faCheckSquare as farCheckSquare, } from '@fortawesome/free-regular-svg-icons';
import { faStackOverflow, faGithub, faMedium, } from '@fortawesome/free-brands-svg-icons';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
// import { RegistrationsContractsDtService } from './guarantees/shared/services/registrations-contracts-dt.service';
import { GuaranteesModule } from './guarantees/profiles/guarantees.module';

import { DevUIGlobalConfig, DevUIGlobalConfigToken } from 'ng-devui/utils';
const custom_global_config: DevUIGlobalConfig = {
  global: {
    showAnimation: true,
  }
};
export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
  ],
  bootstrap: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,

    GuaranteesModule,

    PublicModule,
    BrowserAnimationsModule,
    DevUIModule,
    FontAwesomeModule,
    
    TranslateModule.forRoot({
      defaultLanguage: 'pt',
    })

  ],
  providers: [
    StrategyProviders,
    UtilsProviders,
    TranslateService,
    {
      provide: DevUIGlobalConfigToken,
      useValue: custom_global_config
    },
    // RegistrationsContractsDtService,
    httpInterceptorProviders,
    provideHttpClient(withInterceptorsFromDi())
  ]
})
export class AppModule {
  constructor(library: FaIconLibrary, translate: TranslateService) {
    const i18n = new I18n();
    loadTranslations(i18n, "pt-BR");
    translate.setDefaultLang('pt-BR');
    translate.setTranslation('pt-BR', i18n, true);
    library.addIcons(
      faSquare,
      faCheckSquare,
      farSquare,
      farCheckSquare,
      faStackOverflow,
      faGithub,
      faMedium,
      faBars,
      faTimes
    );
  }
}
