import { inject, Injectable, InjectionToken } from '@angular/core';
import { debounceTime, tap } from 'rxjs';

// import { User } from '@app/shared/models/user-model';
import { createEffect } from '@app/core/utils/create-effect';
import { REGISTRATIONS_CONTRACTS_DT_STORE_TOKEN, LOGGED_USER_SERVICE_TOKEN, APP_STORE } from '@app/guarantees/shared/helpers/tokens/tokens';


import { Signal, effect, untracked } from "@angular/core";

export function explicitEffect<T>(source: Signal<T>, action: (value: T) => void) {
    effect(() => {
        const s = source();
        untracked(() => {
            action(s)
        });
    });
}


@Injectable({ providedIn: 'root' })
export class AppService {

  constructor() {
    // const itemStore = inject(APP_STORE);


  }

  public retrieveContractsData() {
    debounceTime(300)
    const itemStore = inject(REGISTRATIONS_CONTRACTS_DT_STORE_TOKEN);
    console.log('itemStoreContracts ', itemStore.searchDataTable());
  }

  authAccessGuard() {
    const itemStore = inject(LOGGED_USER_SERVICE_TOKEN);
    itemStore.loadUserData();
    if (itemStore.isLogged) {
      const nameRole = itemStore.isAdmin ? 'Administrador' : 'Colaborador';
      const user = { ...itemStore.getUser(), nameRole }
      // this.store.setUser({ user, loadingUser: false });
    }
  }

  // public readonly setUser = createEffect<{
  //   user: User | undefined
  //   loadingUser: boolean
  // }>(_ => _.pipe(
  //   tap(({ user, loadingUser }) => {
  //     const itemStore = inject(LOGGED_USER_SERVICE_TOKEN);
  //     itemStore.loadUserData();
  //     if (itemStore.isLogged) {
  //     }
  //     // this.loggedUserService.loadUserData();

  //     // setTimeout(() => this.store.setUser({ user: { ...user, email: 'teste', nameRole }, loadingUser: false }), 3000);
  //   }
  //   )
  // ));



  // public readonly setSidebarMenuOpen = createEffect<{ sidebarMenuOpen: boolean }>
  //   (_ => _.pipe(tap(({ sidebarMenuOpen }) => this.state.$sidebarMenuOpen.set(sidebarMenuOpen))));

  // public readonly setLoadingGlobal = createEffect<{ loadingGlobal: boolean }>(_ => _.pipe(tap(({ loadingGlobal }) => {
  //   this.state.$loadingGlobal.set(loadingGlobal);
  //   if (this.$loading()) {
  //     this.resultTarget = this.openFullScreen();
  //   } else {
  //     this.resultTarget ? this.resultTarget.loadingInstance.close() : '';
  //     this.resultTarget = undefined;
  //   }
  // })));

}
