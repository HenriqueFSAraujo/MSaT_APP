import { Component, Inject } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Notyf } from 'notyf';

import { DatetimeHelper } from '@app/core/helpers/datetime.helper';
import { CommonService } from '@app/core/services/common.service';
import { pageTransition } from '@app/shared/utils/animations';
import { Images } from '@src/assets/data/images';
import { AlertType } from '@app/shared/components/alert/alert.type';
import { PublicRoutes } from '@app/public/public.routes';
import { AuthService } from '@app/core/auth/auth.service';
import { NOTYF } from '@app/shared/utils/notyf.token';
import { ResetPassword } from './reset-password.model';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css'],
  animations: [pageTransition],
})
export class ResetPasswordComponent {
  readonly signinBannerImage: string = Images.bannerLogo;
  readonly publicRoutes = PublicRoutes;
  readonly currentYear: number = DatetimeHelper.currentYear;
  user: ResetPassword;
  title: string;
  isLoading: boolean = false;

  protected readonly AlertType = AlertType;

  serverErrors: string[] = [];

  mainForm = this.formBuilder.group({
    password: [''],
    repeatPassword: [''],
  });

  constructor(
    public commonService: CommonService,
    private authService: AuthService,
    @Inject(Router) public router: Router,
    @Inject(NOTYF) private notyf: Notyf,
    @Inject(FormBuilder) private formBuilder: FormBuilder,
  ) {
    this.user = { 
      email: '',  
      password: '',
      username: '',
      fullname: '',
      repeatPassword: '',
      link: ''
    };
    this.title = 'Alterar senha';
    this.mainForm = this.createFormGroup();
  }

  protected onFormSubmitHandler = (event: SubmitEvent) => {
    event.preventDefault();
    this.isLoading = true;
    
    if (this.mainForm.valid) {
      
      const formModel = this.mainForm.value;
      let password: string = formModel.password as string;
      let email: string = this.user.email as string;
      let link: string = this.user.link as string;
      let repeatPassword: string = formModel.repeatPassword as string;
      

      (this.authService.resetPassword(password, email, link))
        .subscribe(
          result => {
            if (result === true) {
              setTimeout(() => {
                this.isLoading = false;
                this.notyf.success({
                  message: 'Foi enviado um e-mail com o link para alterar sua senha',
                  duration: 5000
                });
                // commonServices.prepareRoute(appRoutes.Admin, adminRoutes.Dashboard)
              }, 300);
              this.router.navigate(['', PublicRoutes.Signin]);
            } else {
              this.isLoading = false;
              // this.invalidLogin = 'Usu\xE1rio ou senha inv\xE1lido';
              // this.loaderService.hide();
            }
          },
          err => {
            this.isLoading = false;
            console.log('err ', err)
          }
        );
          // err => this.handleError(err));
    } else {
      setTimeout(() => {
        this.mainForm.controls.password.markAsDirty();
        this.mainForm.controls.repeatPassword.markAsDirty();
        this.isLoading = false;      
      }, 1);
    }

  };

  protected onAlertCloseHandler = (e: any) => {
    this.serverErrors = [];
  };

  private createFormGroup(): UntypedFormGroup {
    let group  = new FormGroup({
      password: new FormControl(this.user.password, [ Validators.required, Validators.minLength(5) ] ),
      repeatPassword: new FormControl(this.user.repeatPassword, [ Validators.required, Validators.minLength(5) ] ),
    }, {updateOn: 'change'});

    
    return group;
  }



  ngOnInit(): void {
    let link = this.router['stateManager']['currentUrlTree']['queryParams']['link'];
    console.log(link);
    
    this.authService.resetLinkPasswordParse(link)
    // this.title = 'Login';
    // this.createFormGroup();
    // this.createFormGroupForgot();
    // this.loaderService.hide();
  }

}
