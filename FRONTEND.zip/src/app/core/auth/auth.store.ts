import { Injectable, inject, signal } from '@angular/core';
// import { AuthService } from '@app/core/auth/auth.service';
import { User } from '@app/core/models/user-model';

@Injectable()
export class AuthStore {
    // private readonly authService = inject(AuthService);

    private readonly state = {
        $user: signal<User | undefined>(undefined),
        $loading: signal<boolean>(false),
    } as const;

    // public readonly $loggedIn = this.state.$loggedIn;
    // public readonly $isLoading = this.state.$isLoading;

    public readonly $user = this.state.$user.asReadonly();
    public readonly $loading = this.state.$loading.asReadonly();

    public readonly $setLoading = signal<boolean>(false);
    public readonly $setUser = signal<User | undefined>(undefined);
    

    // public authUser(email: any, password: any) {
    //     try {
    //         this.appStore.setLoadingGlobal({ loadingGlobal: true });
    //         const resp = (this.authService.login(email, password))
    //             .subscribe(
    //                 result => {
    //                     if (result) this.appStore.setUser({ user: result, loadingUser: false });
                        
    //                     return resp;
    //                 },
    //                 err => {
    //                     console.log('err ', err)
    //                     return undefined;
    //                 }
    //             );

    //         setTimeout(() => {
    //             this.appStore.setLoadingGlobal({ loadingGlobal: false });
    //         }, 2000);
    //         const redirUrl: any = this.authService.redirectProfile()
    //         if (resp) return redirUrl; else return undefined;

    //     } catch (error) {
    //         setTimeout(() => {
    //             this.appStore.setLoadingGlobal({ loadingGlobal: false });
    //         }, 1000);
    //         return undefined
    //     }
    // }

}