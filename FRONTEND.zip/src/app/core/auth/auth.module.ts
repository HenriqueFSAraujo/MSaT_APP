import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {AuthRoutingModule} from './auth-routing.module';
import {SigninComponent} from "./signin/signin.component";
import {SignupComponent} from "./signup/signup.component";
import {FormBuilder, FormGroup, ReactiveFormsModule, UntypedFormControl, UntypedFormGroup, Validators} from "@angular/forms";
import {SpinnerComponent} from "@app/shared/components/spinner/spinner.component";
import {ValidationErrorComponent} from "@app/shared/components/validation-error/validation-error.component";
import {AlertComponent} from "@app/shared/components/alert/alert.component";
import { AesService } from '@app/core/utils/aes.service';
import { JwtService } from '@app/core/services/jtw.service';
import { LoggedUserService } from '@app/core/services/logged-user.service';
import { InternalEventService } from '@app/core/tools/internal-event.service';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { AuthGuard } from '@app/core/services/auth-guard.service';
import { RouterLink } from '@angular/router';
import { AlertModule } from 'ng-devui';
import { PublicComponent } from '@src/app/public/public.component';
import { PublicModule } from '@src/app/public/public.module';
import { AuthStore } from './auth.store';
import { AuthService } from './auth.service';
import { StrategyProviders } from '../strategies/strategy.providers';
// import { UtilsProviders } from '../utils/utils.providers';
import { TranslateService } from '@ngx-translate/core';
import { httpInterceptorProviders } from '../interceptors/interceptors.provider';

@NgModule({
  declarations: [
    SigninComponent,
    SignupComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    // PublicComponent
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    ReactiveFormsModule,
    SpinnerComponent,
    ValidationErrorComponent,
    AlertComponent,
    

    
    
  ],
  providers: [
    CommonModule,
    AesService,
    JwtService,
    LoggedUserService,
    AuthGuard,
    InternalEventService,
    RouterLink, FormBuilder, FormGroup,
    UntypedFormControl, UntypedFormGroup, Validators,
    AlertModule,
    AuthStore,
    AuthService,

    StrategyProviders,
    // UtilsProviders,
    TranslateService,
    // RegistrationsContractsDtService,
    httpInterceptorProviders,
    // PublicModule
  ],
  exports: [
    SigninComponent,
    SignupComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    
    
    // PublicComponent
  ]
})
export class AuthModule { }
