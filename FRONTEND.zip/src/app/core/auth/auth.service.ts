import {inject, Inject, Injectable} from '@angular/core';
import { HttpClient, HttpContext, HttpHeaders } from "@angular/common/http";
import {Signin} from "./signin/signin.model";
import {firstValueFrom, map, Observable, tap} from "rxjs";
import {AuthResponse} from "./auth.response";
import { AesService } from '@app/core/utils/aes.service';
import { Token } from '@app/core/models/token-model';
import { JwtService } from '@app/core/services/jtw.service';
import { LoggedUserService } from '@app/core/services/logged-user.service';
import { InternalEventService } from '@app/core/tools/internal-event.service';
import { User } from '@app/core/models/user-model';
import { ActivatedRouteSnapshot, NavigationExtras } from '@angular/router';
import { Router} from '@angular/router';
import { LoggedUser } from '@app/core/models/logged-user-model';
// import { AppStore } from '@app/app.store';
// import { AppRoutes } from '@src/app/app.routes';
// import { AdminRoutes, ProfileAdminRoutes } from '@src/app/admin/admin.routes';
import * as process from 'process';
import { createEffect } from '../utils/create-effect';
import { AuthStore } from './auth.store';
// import * as process from 'process';
// window['process'] = process;

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // private readonly appStore = inject(AppStore);
  redirectUrl: string = '/';
  public user: User;
  // protected readonly store = inject(AuthStore);
  private endpoints: any = {
    login: `/auth/login`,
    passwordRecovery: `/auth/password-recovery`,   
    passwordReset: `/auth/password-reset`,   
  };

  constructor(
    @Inject(AesService) private aesService: AesService,
    // @Inject(AuthStore) private store: AuthStore,
    private httpClient: HttpClient,    
    private router: Router,
    private jwtService: JwtService,
    private loggedUserService: LoggedUserService,
    private internalEventService: InternalEventService
  
  ) { 
    this.user = {
      id: 0,
      firstName: '',
      lastName: '',
      networkName: '',
      username: '',
      password: '',
      email: '',
      termsAccept: false,
      status: '',
    }

    
    console.log('proc',  window['process']);
    console.log('proc',  this.envCreate());
    // console.log('proc', process);
    
    // window['process'] = process;
    
    
  }

  public setUser(user_: User){
    createEffect<{ user: User }>(_ => _.pipe(tap(({ user }) => {
      user = user_;
      // return this.store.$setUser.set(user);
    }))); 
  }
  public getUser(){
    return this.loggedUserService.getUser()
  }

  public setLoading(isLoading: boolean){
    createEffect<{ loading: boolean }>(_ => _.pipe(tap(({ loading }) => {
      loading = isLoading;
      // return this.store.$setLoading.set(loading);
    }))); 
  }



  envCreate(){
    const envs = {
      ...window['process'].env
    }
    return envs
  }

  signIn(data: Signin): Observable<AuthResponse> {
    return this.httpClient.post<AuthResponse>(this.endpoints.signin, data);
  }

  async login(username: string, password: string) {
    const dateStart = new Date().valueOf();
    const dateEnd = new Date().valueOf()+300;
    const body = { 
      username: this.aesService.encryptFromString(`${dateEnd}-W-${username}-W-${dateStart}`), 
      password: this.aesService.encryptFromString(`${dateEnd+1}-W-${password}-W-${dateStart+2}`), 
    };        
    // this.setLoading(true);
    
    let response: any = await firstValueFrom(this.httpClient.post(this.endpoints.login, body));
    const data = { ...response };
    console.log('response 2', data);

    if(data && data?.status && data.status===200){
      const logged = this.extractData(data.object);

      if (logged) {
        this.loggedUserService.loadUserData();  
        this.internalEventService.loggedId();  

        const urlRedirect = this.redirectProfile();
        console.log('urlRedirect', urlRedirect);
        
        if(urlRedirect)
          return urlRedirect
        // setTimeout(() => this.router.navigate([urlRedirect], { queryParams: { },  queryParamsHandling: null}), 200);  
      }

    } else if(data && data?.status && data.status===401){
      response = 401
    }
    
    
    // this.httpClient.post(this.endpoints.login, body).subscribe((data: any) =>{
    //   let logged = this.extractData(data.object);
    //   if (logged) {
    //     this.loggedUserService.loadUserData();        
    //     this.internalEventService.loggedId();    

    //     const user = {...this.loggedUserService.loggedUser};
    //     return  {
    //       email: user.email,
    //       firstName:  user.firstName,
    //       fullname: user.firstName,
    //       lastName: user.lastName,
    //       roles: user.roles,
    //       username: user.username,
    //       urlRedirect: this.redirectProfile()
    //     }
    //   } else {
    //     return undefined;
    //   }  
    // }
      
    // );

    // const response = this.httpClient.post<Token>(this.endpoints.login, body).pipe(map((data:any)=>{
    //   let logged = this.extractData(data.object);
    //   if (logged) {
    //     this.loggedUserService.loadUserData();        
    //     this.internalEventService.loggedId();    

    //     const user = {...this.loggedUserService.loggedUser};
    //     return  {
    //       email: user.email,
    //       firstName:  user.firstName,
    //       fullname: user.firstName,
    //       lastName: user.lastName,
    //       roles: user.roles,
    //       username: user.username,
    //       urlRedirect: this.redirectProfile()
    //     }
    //   } else {
    //     return undefined;
    //   }   
      
    // }));
    return response;
  }

  forgotPassword(email: string): Observable<boolean> {
    const body = {  email: this.aesService.encryptFromString(email)};    
    return this.httpClient.post<Token>(this.endpoints.passwordRecovery, body).pipe(map((data:any)=>{
      if(data.status===200){
        return true; 
      } else {
        return false; 
      }
     }));
  }

  resetPassword(password: string, email: string, link: string): Observable<boolean> {
    const body = {  password: this.aesService.encryptFromString(password), email: this.aesService.encryptFromString(email), link};    
    return this.httpClient.post<Token>(this.endpoints.passwordReset, body).pipe(map((data:any)=>{
      if(data.status===200){
        return true; 
      } else {
        return false; 
      }
     }));
  }

  resetLinkPasswordParse(link_: string){

    let linkEnc: string =  link_    
    .replace(/\-X-/g, '=')
    .replace(/\-W-/g, '/')    
    .replace(/\-K-/g, '+');

    let link: string =  this.aesService.decryptFromString(linkEnc);    
    const linkArr = link.split(',');    
    if(linkArr.length>0&&linkArr?.[0]?.toString()?.length>0){
      const linkResetAt = new Date(linkArr[4]);  
      this.aesService.cookieSet('link', link_, linkResetAt);
      const linkUserId = linkArr[1];
      const linkName = linkArr[2];
      const linkEmail = linkArr[3];   

    } else {    
      // this.snackBar.open('Link para alteração de senha inválido!', 'Fechar', {
      //   duration: 800
      // });
      // this.loaderService.show();
      this.aesService.cookieRemove('link', '/', 'localhost');
      // setTimeout(() => this.router.navigate(['/signin'], { queryParams: { },  queryParamsHandling: null}), 200);  
      // setTimeout(() => this.loaderService.hide(), 595); 
    }

    // let link = this.aesService.decryptFromString('IFEHsYFDoXbb+yZRBquuWlrAPjwES9qSWLiVOJHUxNh532KVNDpoeNnKh2K0kw5mkMpK00kHy9y+AjZjYtJpuw==');
    // const linkArr = link.split(',');
    // this.linkUserId = linkArr[1];
    // this.linkName = linkArr[2];
    // this.linkEmail = linkArr[3];
    // this.linkResetAt = new Date(linkArr[4]);
    
  }

  private extractData(tokenData: Token): boolean {
    const { token } = tokenData;
    const refreshToken = token; 
    const accessToken = this.aesService.decryptFromString(tokenData.accessToken);
    const tokenExp = this.jwtService.getTokenExpirationDate(accessToken);

    const jwtToken: any = this.jwtService.decodeToken(accessToken); 

    if (accessToken) {
      
      this.aesService.cookieSet('token', tokenData.accessToken, tokenExp);

      if (refreshToken) {
        this.aesService.cookieSet('refresh_token', refreshToken, tokenExp);
      }

      (async () => {
        //
      })();

      return true;
    } else {
      return false;
    }
  }

  loggedIn() {
    return this.tokenNotExpired();
  }

  private tokenNotExpired(): boolean {
    const token: any = this.aesService.cookieGet('token') ? this.aesService.decryptFromString(this.aesService.cookieGet('token')) : undefined; 
    return token !== undefined && token !== null && !this.jwtService.isTokenExpired(token);
  }

  checkLogin(url: string, route: ActivatedRouteSnapshot | any): boolean {
    // if(!route) return false;
    let loggedIn: boolean = this.loggedIn();
    let roles = route.data['roles'] as Array<string>;
    let roleAccess: boolean = (roles === undefined || roles.length === 0 || this.loggedUserService.loggerUser.roles.filter(r => roles.indexOf(r) !== -1).length > 0);
    
    
    
    if (loggedIn && roleAccess) { return true; }
    this.redirectUrl = '/signin';
    this.redirect();
    // this.redirectUrl = url;


    return false;
  }

  private redirect() {
    let redirect = this.redirectUrl ? this.redirectUrl : '/';

    let navigationExtras: NavigationExtras = {
      queryParamsHandling: "merge",
      preserveFragment: true
    };

    this.router.navigate([redirect], navigationExtras)
      .then(resolved => {
        if (!resolved) {
          // this.invalidLogin = 'Acesso negado!';
          // this.loaderService.hide();
        }
        else {
          // this.closeDialog();
          // this.loaderService.hide();
        }
      });
  }

  public redirectProfile() {
    const roles = JSON.parse(JSON.stringify(this.loggedUserService.loggerUser?.roles || '[]'));
    let urlRedirect = '';
    if(roles && roles.length>0){
      console.log('roles ', roles);
      if(roles[0]==='ROLE_ADMIN'){
        urlRedirect = 'profile/admin/dashboard'
      }
      return urlRedirect
    } else {
      return undefined
    }

  }

  clearUser(): void {
    let authToken = this.aesService.cookieGet('token');
    if (authToken !== undefined && authToken !== null && authToken !== '') {        
      this.aesService.cookieRemove('token');
      this.aesService.cookieRemove('refresh_token');
      this.loggedUserService.loggerUser = new LoggedUser(null);
    }
  }

  logout(): void {
    this.clearUser();
    this.internalEventService.loggedOut();
    this.router.navigate(['/signin']);
  }
}
