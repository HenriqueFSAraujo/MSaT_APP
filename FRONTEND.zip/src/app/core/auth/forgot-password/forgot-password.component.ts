import { Component, Inject } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Notyf } from 'notyf';

import { DatetimeHelper } from '@app/core/helpers/datetime.helper';
import { CommonService } from '@app/core/services/common.service';
import { pageTransition } from '@app/shared/utils/animations';
import { Images } from '@src/assets/data/images';
import { AlertType } from '@app/shared/components/alert/alert.type';
import { PublicRoutes } from '@app/public/public.routes';
import { AuthService } from '@app/core/auth/auth.service';
import { User } from '@app/core/models/user-model';
import { NOTYF } from '@app/shared/utils/notyf.token';


// import { AdminRoutes } from 'src/app/admin/admin.routes';
// import { AppRoutes } from 'src/app/app.routes';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
  animations: [pageTransition],
})
export class ForgotPasswordComponent {
  readonly signinBannerImage: string = Images.bannerLogo;
  readonly publicRoutes = PublicRoutes;
  readonly currentYear: number = DatetimeHelper.currentYear;
  user: User;
  title: string;
  isLoading: boolean = false;

  protected readonly AlertType = AlertType;

  serverErrors: string[] = [];

  mainForm = this.formBuilder.group({
    email: [''],
  });

  constructor(
    public commonService: CommonService,
    private authService: AuthService,
    @Inject(Router) public router: Router,
    @Inject(NOTYF) private notyf: Notyf,
    @Inject(FormBuilder) private formBuilder: FormBuilder,
  ) {
    this.user = { email: '' };
    this.title = 'Esqueci a senha';
    this.mainForm = this.createFormGroup();
  }

  protected onFormSubmitHandler = (event: SubmitEvent) => {
    event.preventDefault();
    this.isLoading = true;
    
    if (this.mainForm.valid) {
      
      const formModel = this.mainForm.value;
      let email: string = formModel.email as string;
      

      (this.authService.forgotPassword(email))
        .subscribe(
          result => {
            if (result === true) {
              setTimeout(() => {
                this.isLoading = false;
                this.notyf.success({
                  message: 'Foi enviado um e-mail com o link para alterar sua senha',
                  duration: 5000
                });
                // commonServices.prepareRoute(appRoutes.Admin, adminRoutes.Dashboard)
              }, 300);
              this.router.navigate(['', PublicRoutes.Signin]);
            } else {
              this.isLoading = false;
              // this.invalidLogin = 'Usu\xE1rio ou senha inv\xE1lido';
              // this.loaderService.hide();
            }
          },
          err => {
            this.isLoading = false;
            console.log('err ', err)
          }
        );
          // err => this.handleError(err));
    } else {
      setTimeout(() => {
        this.mainForm.controls.email.markAsDirty();
        this.isLoading = false;      
      }, 1);
    }

  };

  protected onAlertCloseHandler = (e: any) => {
    this.serverErrors = [];
  };

  private createFormGroup(): UntypedFormGroup {
    let group  = new FormGroup({
      email: new FormControl(this.user.email, [ Validators.required, Validators.minLength(5) ] ),
    }, {updateOn: 'change'});

    
    return group;
  }



  ngOnInit(): void {
    // this.title = 'Login';
    // this.createFormGroup();
    // this.createFormGroupForgot();
    // this.loaderService.hide();
  }

}
