export interface ForgotPassword {
    email: string;    
}