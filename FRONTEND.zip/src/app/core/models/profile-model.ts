
export class Profile {
  id!: number;
  description!: string;
  selected!: boolean;
}
