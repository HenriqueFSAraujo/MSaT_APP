export class LoggedUser {
  username?: string;
  email?: string;
  roles: Array<string>;
  firstName?: string;
  fullname?: string;
  lastName?: string;
  password?: string;
  nameRole?: string;
  originUserToken!: string;

  constructor(token: any) {
    
    this.roles = new Array<string>();
   
    if (token !== undefined && token !== null && token.user !== undefined) {
      const roles = token.user.roles.map((role: any)=>role.name)
      this.username = token.user.username;
      this.fullname = token.user.fullname;
      this.email = token.user.email;
      this.firstName =  token?.user?.fullname?.toString()?.includes(' ') ? token.user.fullname.split(' ')[0] : '';
      this.lastName = token?.user?.fullname?.toString()?.includes(' ') ? token.user.fullname.split(' ')[1] : '';

      if (token?.originUserToken) {
        this.originUserToken = token.originUserToken;
      }
      
      if (roles !== undefined) {
        if (roles instanceof Array) {
          roles.forEach( (role: string) => {
            this.roles.push(role);
          });
        } else {
          this.roles.push(roles);
        }
      }
    }
  }
}
