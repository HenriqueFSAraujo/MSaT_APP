export class Paging<T> {
  totalElements: number;
  sum: number;
  content: T[];
}
