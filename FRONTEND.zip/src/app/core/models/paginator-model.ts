export class Paginator {
  page!: number;
  pageSize!: number;
  sort!: string;
  sortDirection!: string;
}
