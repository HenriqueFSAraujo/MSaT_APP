export class User {
  id?: number;
  firstName?: string;
  lastName?: string;
  networkName?: string;
  username?: string;
  fullname?: string;
  password?: string;
  email?: string;
  termsAccept?: boolean;
  status?: string;
  nameRole?: string;
  profiles?: string[];
}
