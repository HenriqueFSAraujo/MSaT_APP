import { isObservable, Observable, of, retry, Subject, Subscription } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DestroyRef, inject, Signal, effect, untracked } from '@angular/core';

export function createEffect<
  ProvidedType = void,
  OriginType extends | Observable<ProvidedType> | unknown = Observable<ProvidedType>,
  ObservableType = OriginType extends Observable<infer A> ? A : never,
  ReturnType = ProvidedType | ObservableType extends void
  ? (
    observableOrValue?: ObservableType | Observable<ObservableType>
  ) => Subscription
  : (
    observableOrValue: ObservableType | Observable<ObservableType>
  ) => Subscription
>(generator: (origin$: OriginType) => Observable<unknown>): ReturnType {

  const destroyRef = inject(DestroyRef);
  const origin$ = new Subject<ObservableType>();
  generator(origin$ as OriginType).pipe(
    retry(),
    takeUntilDestroyed(destroyRef)
  ).subscribe();

  return ((
    observableOrValue?: ObservableType | Observable<ObservableType>
  ): Subscription => {
    const observable$ = isObservable(observableOrValue)
      ? observableOrValue.pipe(retry())
      : of(observableOrValue);
    return observable$.pipe(takeUntilDestroyed(destroyRef)).subscribe((value) => {
      origin$.next(value as ObservableType);
    });
  }) as unknown as ReturnType;
}



export function explicitEffect<T>(source: Signal<T>, action: (value: T) => void) {
    effect(() => {
        const s = source();
        untracked(() => {
            action(s)
        });
    });
}

export function explicitEffect2<T>(source: Signal<T>, action: (value: T) => void) {
    effect(() => {
        const s = source();
        untracked(() => {
            action(s)
        });
    });
}
