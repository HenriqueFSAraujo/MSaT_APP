export class DatetimeHelper{
    public static readonly currentYear : number = new Date().getFullYear();
}