export const ERROR_MESSAGES = {
  required: () => "This field is required",
}
