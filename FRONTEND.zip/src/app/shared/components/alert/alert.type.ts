export enum AlertType {
  Success,
  Warning,
  Danger,
  Info,
}
