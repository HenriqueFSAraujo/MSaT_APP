import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '@app/public/home/home.component';
import { PublicRoutes } from '@app/public/public.routes';
import { SignupComponent } from '@app/core/auth/signup/signup.component';
import { SigninComponent } from '@app/core/auth/signin/signin.component';
import { ForgotPasswordComponent } from '@app/core/auth/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from '@app/core/auth/reset-password/reset-password.component';

const routes: Routes = [
  {
    path: '',
    title: 'Home',
    component: HomeComponent,
  },
  {
    title: "Signin",
    path: PublicRoutes.Signup,
    component: SignupComponent
  },
  {
    title: "Acesso",
    path: PublicRoutes.Signin,
    component: SigninComponent
  },
  {
    title: "Esqueci a senha",
    path: PublicRoutes.forgotPass,
    component: ForgotPasswordComponent
  },
  {
    title: "Alterar senha",
    path: PublicRoutes.resetPass,
    component: ResetPasswordComponent
  },
  // {
  //   path: '',
  //   loadChildren: () => import('./auth/auth.module').then((m) => m.AuthModule),
  // },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PublicRoutingModule {}
