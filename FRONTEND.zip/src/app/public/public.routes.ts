export enum PublicRoutes {
  Home = '',
  Signup = 'signup',
  Signin = 'signin',
  forgotPass = 'forgot-password',
  resetPass = 'reset-password',
}
