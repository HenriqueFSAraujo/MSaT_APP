export interface RegistrationsContractsDtModel {
    id: number;
    creditor: string;
    orderCreatedAt: Date;
    contractNum: string;
    carPlate: string;
    carModel: string;
    currentStage: string;
    seizureStatus: string;
    lastMoveUpdatedAt: Date;

    $checked?: boolean;
    $expandConfig?: any;
    children?: any;
    chosen?: boolean;
    $isChildTableOpen?: boolean;
 }