export interface VehicleDetails {
    brandModelVersion: string; 
    plate: string;             
    state: string;             
    color: string;             
    manufactureYear: number;     
    modelYear: number;         
    chassis: string;           
    renavam: string;      
    cityState: string;     
  }

  export interface ConsultationResult {
    seizureStatus: string;     // Status de apreensão
    seizureDateTime: Date;     // Data e Hora apreensão do veículo
    lastMovementDate: Date;    
    vehicleLocation: string;   
    currentStep: string;       // Etapa Atual
    seizureSchedule: Date;     // Agendamento da apreensão
  }

  export interface CreditorData {
    company: string;           
    email: string;            
    cpfCnpj: string;           
    adress: string;
    phone: string;             
  }

  export interface ServentiaData {
    name: string;             
    cns: string;               
    phone: string;            
    address: string;           
    responsibleOfficer: string;// Oficial responsável
    substituteOfficer: string; // Substituto
  }
  
  export interface DebtorData {
    name: string;              
    cpfCnpj: string;           
    type: string;              
  }
  
  export interface CollectionOfficeData {
    company: string;           
    email: string;             
    cpfCnpj: string;           
    phone: string;             
    address: string;           
    responsibleName: string;   
  }

  export interface TowTruckData {
    company: string;           
    email: string;             
    cpfCnpj: string;           
    phone: string;             
    address: string;           
    responsibleName: string;   
  }
  
  export interface YardData {
    company: string;           
    email: string;             
    cpfCnpj: string;           
    phone: string;             
    address: string;           
    type: string;              
    responsibleName: string;  
  }
  
  export interface Address {
    street: string;            
    number: string;            
    neighborhood: string;      
    state?: string;           
  }

  export interface ContractDetailModal {
    vehicleDetails: VehicleDetails;
    consultationResult: ConsultationResult;
    creditorData: CreditorData;
    serventiaData: ServentiaData;
    debtors?: DebtorData[] | undefined;            
    collectionOfficeData: CollectionOfficeData;
    towTruckData: TowTruckData;
    yardData: YardData;
    billingAddresses?: Address[] | undefined;      // Array para endereços de cobrança (ultimas sections modal)
    probableAddresses?: Address[];     // Array para endereços prováveis (talvez gerar um componente proprio)
  }
