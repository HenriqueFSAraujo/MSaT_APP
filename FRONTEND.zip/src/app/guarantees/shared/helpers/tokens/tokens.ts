import { RegistrationsContractsDtStore } from '@app/guarantees/shared/stores/registrations-contracts-dt.store';
import { inject, InjectionToken } from '@angular/core';
import { LoggedUserService } from '@app/core/services/logged-user.service';
import { AppStore } from '@src/app/app.store';
import { SidebarStore } from '@src/app/guarantees/profiles/admin/layouts/sidebar/sidebar.store';
import { InternalEventService } from '@src/app/core/tools/internal-event.service';
export const REGISTRATIONS_CONTRACTS_DT_STORE_TOKEN = new InjectionToken<RegistrationsContractsDtStore>('Active theme', { factory() {  
  return inject(RegistrationsContractsDtStore) }
});

export const LOGGED_USER_SERVICE_TOKEN = new InjectionToken<LoggedUserService>('Active theme', { factory() {  
  return inject(LoggedUserService) }
});

export const APP_STORE = new InjectionToken<AppStore>('Active theme', { factory() {  
  return inject(AppStore) }
});

export const SIDE_BAR_PROFILE_ADMIN_STORE = new InjectionToken<SidebarStore>('SIDE_BAR_PROFILE_ADMIN_STORE', { factory() {  
  return inject(SidebarStore) }
});

export const INTERNAL_EVENT_SERVICE = new InjectionToken<InternalEventService>('INTERNAL_EVENT_SERVICE', { factory() {  
  return inject(InternalEventService) }
});


// export function notyfFactory(): Notyf {
//   return new Notyf({
//     position: {x: 'center', y: 'bottom'},
//     duration: 10000,
//     dismissible: true,
//   });
// }