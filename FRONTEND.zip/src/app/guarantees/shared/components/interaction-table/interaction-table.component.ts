import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DataTableComponent, SortDirection, SortEventArg, TableWidthConfig, tableResizeFunc } from 'ng-devui/data-table';
import { originSource, SourceType } from '../../mock-data/contracts';
import { NgIf, NgFor, NgTemplateOutlet } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DevUIModule } from 'ng-devui';
// import { SourceType, originSource } from '../shared/mock-data';


@Component({
    selector: 'd-interaction-table',
    templateUrl: './interaction-table.component.html',
    styleUrls: ['./interaction-table.component.scss'],
    standalone: true,
    imports: [NgIf, NgFor,  DevUIModule, FontAwesomeModule, NgTemplateOutlet, ],
})
export class InteractionTableComponent implements OnInit {
    @ViewChild(DataTableComponent, { static: true }) datatable: DataTableComponent | any;
    sortableDataSource: Array<SourceType> = JSON.parse(JSON.stringify(originSource.slice(0, 6)));
    filterListRadio = [
        {
            name: 'Clear',
            value: 'Clear',
        }, {
            name: 'Male',
            value: 'Male',
        }, {
            name: 'Female',
            value: 'Female',
        }
    ];

    firstFilterList = [
        {
            name: 'Mark',
            value: 'Mark'
        },
        {
            name: 'Jacob',
            value: 'Jacob'
        },
        {
            name: 'Danni',
            value: 'Danni'
        },
        {
            name: 'green',
            value: 'green'
        },
        {
            name: 'po',
            value: 'po'
        },
        {
            name: 'john',
            value: 'john'
        },

    ];

    filterListMulti = JSON.parse(JSON.stringify(originSource.slice(0, 6)));
    tableWidthConfig: TableWidthConfig[] = [
        {
            field: 'checkbox',
            width: '41px'
        },
        {
            field: '$index',
            width: '100px'
        },
        {
            field: 'firstName',
            width: '100px'
        },
        {
            field: 'lastName',
            width: '100px'
        },
        {
            field: 'gender',
            width: '100px'
        },
        {
            field: 'dob',
            width: '100px'
        },
        {
            field: 'description',
            width: '100px'
        }
    ];

    lastNameSortDirection = SortDirection.ASC;
    genderSortDirection = SortDirection.default;
    sortParams = { field: 'lastName', direction: this.lastNameSortDirection };
    checkboxList = [];
    allChecked = false;
    halfChecked = false;
    filterIconActive = false;

    constructor(
        private ref: ChangeDetectorRef,
        private ele: ElementRef
      ) {
        // this.datatable = new DataTableComponent(ref, ele)

       }
      ngOnInit() {
        this.checkboxList = JSON.parse(JSON.stringify(originSource.slice(0, 6)));
        // this.sortableDataSource[0]['checkDisabled'] = true;
      }

    onSortChange(event: SortEventArg, field: any) {
        this.sortParams = {
            field: field,
            direction: event.direction
        };
    }

    onResize = tableResizeFunc(this.tableWidthConfig, this.ele);

    filterChangeRadio(event: any) {
        if (event.name === 'Clear') {
            this.sortableDataSource = JSON.parse(JSON.stringify(originSource.slice(0, 6)));
            return;
        }
        const filterList = event.name;
        const dataDisplay: any = [];
        JSON.parse(JSON.stringify(originSource.slice(0, 6))).forEach((item: any) => {
            if (filterList.includes(item.gender)) {
                dataDisplay.push(item);
            }
        });
        this.sortableDataSource = dataDisplay;
    }

    onFirstFilterChange(event: any) {
        const filterList = event.map((item: any) => item.name);
        const dataDisplay: any = [];
        JSON.parse(JSON.stringify(originSource.slice(0, 6))).forEach((item: any) => {
            if (filterList.includes(item.firstName)) {
                dataDisplay.push(item);
            }
        });
        this.sortableDataSource = dataDisplay;
    }

    beforeFilter = (currentValue: any) => {
        this.filterListMulti = this.firstFilterList;
        this.ref.detectChanges();
        return true;
    };

    onRowCheckChange(checked: any, rowIndex: any, nestedIndex: any, rowItem: any) {
        console.log('rowItem', rowItem);
        rowItem.$checked = checked;
        rowItem.$halfChecked = false;
        this.datatable.setRowCheckStatus({
          rowIndex: rowIndex,
          nestedIndex: nestedIndex,
          rowItem: rowItem,
          checked: checked
        });
    }

    onCheckboxChange(event: any, name: any) {
        this.setHalfChecked();
    }
    setHalfChecked() {
        this.halfChecked = false;
        const chosen = this.checkboxList.filter((item: any) => item.chosen);
        if (chosen.length === this.checkboxList.length) {
            this.allChecked = true;
        } else if (chosen.length > 0) {
            this.halfChecked = true;
        } else {
            this.allChecked = false;
            this.halfChecked = false;
        }
    }

    filterSource(dropdown: any) {
        this.sortableDataSource = this.checkboxList.filter((item: any) => item.chosen);
        this.filterIconActive = true;
        dropdown.toggle();
    }

    cancelFilter(dropdown: any) {
        dropdown.toggle();
    }

    getCheckedRows() {
        const rows = this.datatable.getCheckedRows();
        console.log(rows);
    }

    onToggle(data: any) {
        console.log('onToggle ---', data);
    }
}
