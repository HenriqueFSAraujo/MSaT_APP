import { ChangeDetectionStrategy, Component, Input, OnInit, ViewChild } from '@angular/core';
import { DataTableComponent as DtComponent, TableCheckOptions } from 'ng-devui/data-table';
import { DevUIModule, TableWidthConfig } from 'ng-devui';
import { NgFor, NgIf, NgTemplateOutlet } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { I18nDatePipe } from 'ng-devui/i18n';
import { IconModule } from 'ng-devui/icon';
import { DropDownMenuComponent } from '../dropdown-menu/dropdown-menu.component';
@Component({
  selector: 'app-data-table',
  standalone: true,
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css'],
  providers: [I18nDatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [NgIf, NgFor, DevUIModule, FontAwesomeModule, NgTemplateOutlet, IconModule, DropDownMenuComponent],
})
export class DataTableComponent implements OnInit {
  @ViewChild(DtComponent, { static: true })
  dataTable!: DtComponent;
  
  bufferSource: Array<any> = JSON.parse(JSON.stringify([{ id: 1 }]));
  basicDataSource: Array<any> = JSON.parse(JSON.stringify(this.bufferSource.slice(0, 6)));

  @Input()
  dataSource: any = [{ checked: true }]

  @Input()
  tableWidthConfig: TableWidthConfig[] = [{  field: 'checkbox', width: '41px' }]

  @Input()
  tableOptions: any = { columns: [{ field: 'checkbox', width: '41px' }] };

  constructor() { }

  ngOnInit() {
    this.bufferSource = JSON.parse(JSON.stringify(this.dataSource));
    this.basicDataSource = JSON.parse(JSON.stringify(this.bufferSource.slice(0, 20)));
  };

  updateScrollSize() {
    this.dataTable?.updateVirtualScrollSize();
  }

  checkOptions: TableCheckOptions[] = [
    {
      label: '',
      onChecked: this.checkTotalData.bind(this)
    },
    {
      label: '',
      onChecked: this.checkPageData.bind(this)
    }
  ];

  pager = {
    total: 12,
    pageIndex: 1,
    pageSize: 20
  };

  totalDataChecked = false;
  allCheckedStatus = false;

  checkTotalData() {
    console.log('checkTotalData');
    this.dataTable?.setTableCheckStatus(
      {
        pageAllChecked: true
      }
    );
    this.totalDataChecked = true;
    this.allCheckedStatus = true;
    this.bufferSource = this.bufferSource.map(item => ({ $checked: true, ...item }));
  }

  checkAllChange(checked: boolean) {
    console.log('checkAllChange', checked);
    
    this.allCheckedStatus = checked;

    this.updateCurrentPageDataCheck(checked);
  }

  checkPageData() {
    console.log('checkPageData');
    this.dataTable?.setTableCheckStatus(
      {
        pageAllChecked: true
      }
    );
    this.totalDataChecked = false;
    this.allCheckedStatus = true;

    this.updateCurrentPageDataCheck(true);
  }

  onRowCheckChange(checked: boolean, rowIndex: number, nestedIndex:string, rowItem: any) {
    
    // if(dataItem.$checked===checked) return
    rowItem.$checked = checked;
    rowItem.$halfChecked = false;
    this.dataTable.setRowCheckStatus({
      rowIndex: rowIndex,
      nestedIndex: nestedIndex,
      rowItem: rowItem,
      checked: checked
    });
    const dataItem = this.bufferSource.find(item => item.id === rowItem.id);
    
    dataItem.$checked = checked;

    if (checked) {
      this.totalDataChecked = this.basicDataSource.every(item => item.$checked);
      this.allCheckedStatus = this.bufferSource.every(item => item.$checked);
    } else {
      this.totalDataChecked = false;
      this.allCheckedStatus = false;
    }

    console.log('dataItem', dataItem);
    
  }

  onPageIndexChange(pageIndex: number) {
    console.log('onPageIndexChange');
    const startIndex = (pageIndex - 1) * this.pager.pageSize;
    const lastIndex = pageIndex * this.pager.pageSize;
    this.basicDataSource = this.bufferSource.slice(startIndex, lastIndex);
  }

  private updateCurrentPageDataCheck(checked: boolean) {
    console.log('updateCurrentPageDataCheck');
    
    console.log(this.bufferSource);
    
    const startIndex = (this.pager.pageIndex - 1) * 20;
    for (let i = startIndex; i < this.pager.pageSize; i++) {
      this.bufferSource[i].$checked = checked;
    }
  }

}
