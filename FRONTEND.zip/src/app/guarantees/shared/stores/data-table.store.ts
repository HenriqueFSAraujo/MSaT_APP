import { Injectable, inject, signal } from '@angular/core';
import { AppStore } from "@app/app.store";
import { AuthService } from '@app/core/auth/auth.service';
import {  DataTableModel } from '../models/data-table-model';
import { catchError, MonoTypeOperatorFunction, Observable, of, tap } from 'rxjs';
import { DataTableService } from '../services/data-table.service';
import { createEffect } from '@app/core/utils/create-effect';

@Injectable()
export class DataTableStore {
  // private readonly appStore = inject(AppStore);
  // private readonly authService = inject(AuthService);
  private readonly dataTableService = inject(DataTableService);

  private readonly state = {
    // $loggedIn: this.appStore.$setLoggedIn(),
    $isLoading: signal(false),
    $dataTable: signal<any| undefined>(undefined),

  } as const;

  // public readonly $loggedIn = this.state.$loggedIn;
  public readonly $isLoading = this.state.$isLoading;

  public readonly $dataTable = this.state.$dataTable.asReadonly();
  public readonly $setDataTable = signal<any | undefined>(undefined);
  
  public readonly setDataTable = createEffect<{
    dataTable: any,
  }>((params$) =>
    params$.pipe(
      tap(({ dataTable }) => {
        console.log(dataTable);
        this.state.$dataTable.set(dataTable);
      })
    )
  );

  public searchDataTable() {
    const dataTable: any = this.dataTableService.searchData();
    this.setDataTable({dataTable}); //return this.dataTableService.searchData();
   
  }


}