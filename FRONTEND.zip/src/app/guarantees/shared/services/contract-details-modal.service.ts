import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { ContractDetailModal } from '../models/contract-details-modal.model';
import { mockModalDetails } from '../mock-data/contracts';


@Injectable({
    providedIn: 'root'
})
export class ContractDetailService {

    constructor() { }

    getContractDetails(){
      return mockModalDetails;
    } 
}
