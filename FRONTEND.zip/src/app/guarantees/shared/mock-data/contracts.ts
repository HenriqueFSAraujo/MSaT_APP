export interface SourceType {
    id?: number;
    firstName: string;
    lastName: string;
    dob: Date;
    gender: string;
    detail?: string;
    $checked?: boolean;
    $expandConfig?: any;
    children?: any;
    chosen?: boolean;
    $isChildTableOpen?: boolean;
  }
  
  export const originSource = [
    {
      id: 1,
      firstName: 'Mark',
      lastName: 'Otto',
      dob: new Date(1990, 12, 1),
      gender: 'Male',
      description: 'handsome man'
    },
    {
      id: 2,
      firstName: 'Jacob',
      lastName: 'Thornton',
      gender: 'Female',
      dob: new Date(1989, 1, 1),
      description: 'interesting man'
    },
    {
      id: 3,
      firstName: 'Danni',
      lastName: 'Chen',
      gender: 'Female',
      dob: new Date(1991, 3, 1),
      description: 'pretty man',
      expandConfig: {description: 'Danni is here'}
    },
    {
      id: 4,
      firstName: 'green',
      lastName: 'gerong',
      gender: 'Male',
      description: 'interesting man',
      dob: new Date(1991, 3, 1),
    },
    {
      id: 5,
      firstName: 'po',
      lastName: 'lang',
      gender: 'Male',
      dob: new Date(1991, 3, 1),
      description: 'lang is here',
    },
    {
      id: 6,
      firstName: 'john',
      lastName: 'li',
      gender: 'Female',
      dob: new Date(1991, 3, 1),
      description: 'pretty man',
    },
    {
      id: 7,
      firstName: 'peng',
      lastName: 'li',
      gender: 'Female',
      dob: new Date(1991, 3, 1),
    },
    {
      id: 8,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: 'Female',
      dob: new Date(1991, 3, 1),
    },
    {
      id: 9,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: 'Female',
      dob: new Date(1991, 3, 1),
      detail: '这是另外一个行详情'
    },
    {
      id: 10,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: 'Female',
      dob: new Date(1991, 3, 1),
    },
    {
      id: 11,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: 'Female',
      dob: new Date(1991, 3, 1),
    },
    {
      id: 12,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: 'Female',
      dob: new Date(1991, 3, 1),
    },
  ];
  
  export const editableOriginSource = [
    {
      id: 1,
      firstName: 'Mark',
      lastName: 'Otto',
      dob: new Date(1990, 12, 1),
      gender: { id: 1, label: 'Male' },
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 2,
      firstName: 'Jacob',
      lastName: 'Thornton',
      gender: { id: 2, label: 'Female' },
      dob: new Date(1989, 1, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 3,
      firstName: 'Danni',
      lastName: 'Chen',
      gender: { id: 2, label: 'Female' },
      dob: new Date(2018, 3, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 4,
      firstName: 'green',
      lastName: 'gerong',
      gender: { id: 1, label: 'Male' },
      dob: new Date(2018, 3, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 5,
      firstName: 'po',
      lastName: 'lang',
      gender: { id: 1, label: 'Male' },
      dob: new Date(2018, 3, 1),
      detail: '这是一个行详情',
      age: 24,
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 6,
      firstName: 'john',
      lastName: 'li',
      gender: { id: 2, label: 'Female' },
      dob: new Date(2018, 3, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 7,
      firstName: 'peng',
      lastName: 'li',
      gender: { id: 2, label: 'Female' },
      dob: new Date(2018, 3, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 8,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: { id: 2, label: 'Female' },
      dob: new Date(2018, 3, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 9,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: { id: 2, label: 'Female' },
      dob: new Date(2018, 3, 1),
      detail: '这是另外一个行详情',
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 10,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: { id: 2, label: 'Female' },
      dob: new Date(2018, 3, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 11,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: { id: 2, label: 'Female' },
      dob: new Date(2018, 3, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
    {
      id: 12,
      firstName: 'Danni',
      lastName: 'Yu',
      gender: { id: 2, label: 'Female' },
      dob: new Date(2018, 3, 1),
      age: 24,
      hobby: [{ id: 1, name: 'music' },
        { id: 2, name: 'football' }],
      duty: [{
        'title': '前端维护',
        'id': 9
      }, {
        'title': '后台维护',
        'disabled': true,
        'isChecked': true,
        'id': 10
      }]
    },
  ];
  
  export const genderSource = [
    { id: 1, label: 'Male' },
    { id: 2, label: 'Female' }
  ];
  
  export const hobbySource = [
    { id: 1, name: 'music' },
    { id: 2, name: 'football' },
    { id: 3, name: 'game' },
    { id: 4, name: 'anime' }
  ];
  
  export const DutySource = [
    {
      'id': 8,
      'title': '维护',
      'open': true,
      'halfChecked': true,
      'children': [
        {
          'title': '前端维护',
          'id': 9
        }, {
          'title': '后台维护',
          'disabled': true,
          'isChecked': true,
          'id': 10
        },
        {
          'title': '数据库维护',
          'disabled': true,
          'id': 11
        }
      ]
    },
    {
      'id': 15,
      'title': '管理',
      'children':
        [
          {
            'title': '向导',
            'id': 16
          }, {
            'title': '配置',
            'id': 17
          }
        ]
    }
  ];
  
  export const treeDataSource = [
    {
      title: 'table title0',
      lastName: 'Mark',
      dob: new Date(1990, 12, 1),
      status: 'done',
      startDate: new Date(2020, 1, 5),
      endDate: new Date(2020, 1, 8),
      children: [
        {
          title: 'table title01',
          lastName: 'Mark',
          status: 'done',
          dob: new Date(1989, 1, 1),
          children: [
            {
              title: 'table title011',
              lastName: 'Mark',
              status: 'done',
              dob: new Date(1989, 1, 1),
            },
            {
              title: 'table title012',
              lastName: 'Mark',
              status: 'done',
              dob: new Date(1991, 3, 1),
              children: [
                {
                  title: 'table title0121',
                  lastName: 'Mark',
                  status: 'done',
                  dob: new Date(1989, 1, 1)
                },
                {
                  title: 'table title0122',
                  lastName: 'Mark',
                  status: 'done',
                  dob: new Date(1989, 1, 1)
                }
              ]
            }
          ]
        },
        {
          title: 'table title02',
          lastName: 'Mark',
          status: 'done',
          dob: new Date(1991, 3, 1)
        }
      ]
    },
    {
      title: 'table title1',
      lastName: 'Mark',
      status: 'done',
      dob: new Date(1989, 1, 1),
      startDate: new Date(2020, 1, 4),
      endDate: new Date(2020, 1, 8),
      children: []
    },
    {
      title: 'table title2',
      lastName: 'Mark',
      status: 'done',
      dob: new Date(1991, 3, 1),
      startDate: new Date(2020, 1, 6),
      endDate: new Date(2020, 1, 9),
    },
    {
      title: 'table title3',
      lastName: 'Mark',
      status: 'done',
      dob: new Date(1991, 3, 1),
      detail: '这是一个行详情',
      startDate: new Date(2020, 1, 7),
      endDate: new Date(2020, 1, 10),
    },
    {
      title: 'table title4',
      lastName: 'Mark',
      status: 'done',
      dob: new Date(1991, 3, 1),
      startDate: new Date(2020, 1, 7),
      endDate: new Date(2020, 1, 12),
    }

    
  ];

  export const mockModalDetails = {
    vehicleDetails: {
      brandModelVersion: 'HYUNDAI/HB20 1.0M VISION',
      plate: 'FEL2525',
      state: 'SP',
      color: 'Branco',
      manufactureYear: 2023,
      modelYear: 2023,
      chassis: '9C6KC16703R035349',
      renavam: '87455842106',
      cityState: 'São Paulo/SP'
    },
    consultationResult: {
      seizureStatus: 'Aguardando execução',
      seizureDateTime: new Date('2024-09-10T10:00:00'),
      lastMovementDate: new Date('2024-09-01T14:30:00'),
      vehicleLocation: 'Pátio Central',
      currentStep: 'Notificação emitida',
      seizureSchedule: new Date('2024-09-15T08:00:00')
    },
    creditorData: {
      company: 'Credor XYZ',
      email: 'contato@credorxyz.com.br',
      cpfCnpj: '12.345.678/0001-90',
      adress: 'Rua dos Credores, 100, Centro, São Paulo/SP',
      phone: '(11) 1234-5678'
    },
    serventiaData: {
      name: '2º RTDPU de São Paulo',
      cns: '5479',
      phone: '(11) 98765-4321',
      address: 'Rua Desembargador, n 30, Bairro Ouro Preto, Belo Horizonte, Minas Gerais',
      responsibleOfficer: 'Ricardo Almeida Junior Santos do Carmo',
      substituteOfficer: 'Luiz Almeida Junior Santos do Carmo'
    },
    debtors: [
      {
        name: 'Fagner Alves da Silva',
        cpfCnpj: '548.654.875-67',
        type: 'Devedor'
      },
      {
        name: 'Jonas Albertino Alves da Silva',
        cpfCnpj: '123.456.987-65',
        type: 'Garantidor'
      }
    ],
    collectionOfficeData: {
      company: 'Empresa X',
      email: 'setor@empresax.com.br',
      cpfCnpj: '99.999.999/9999-08',
      phone: '(31) 99999-9999',
      address: 'Rua Desembargador, n 30, Bairro Ouro Preto, Belo Horizonte, Minas Gerais',
      responsibleName: 'Jonas Adalberto Silva'
    },
    towTruckData: {
      company: 'Empresa Y',
      email: 'setor@guincho.com.br',
      cpfCnpj: '99.999.999/9999-08',
      phone: '(31) 99999-9999',
      address: 'Rua Desembargador, n 30, Bairro Ouro Preto, Belo Horizonte, Minas Gerais',
      responsibleName: 'Ricardo Bernardes Alves'
    },
    yardData: {
      company: 'Empresa Y',
      email: 'setor@patio.com.br',
      cpfCnpj: '99.999.999/9999-08',
      phone: '(31) 99999-9999',
      address: 'Rua Desembargador, n 30, Bairro Ouro Preto, Belo Horizonte, Minas Gerais',
      type: 'Intermediário',
      responsibleName: 'Lucca Silva Dianito'
    },
    billingAddresses: [
      {
        street: 'Avenida Seu Futuro Presente',
        number: '28',
        neighborhood: 'Sagrada Família',
        state: 'Minas Gerais'
      }
    ],
    probableAddresses: [
      {
        street: 'Avenida Seu Futuro Presente',
        number: '28',
        neighborhood: 'Sagrada Família',
        state: 'Minas Gerais'
      }
    ]
  };