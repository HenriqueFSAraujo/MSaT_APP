import { CommonModule } from '@angular/common';
import { NumberTransModule } from 'ng-devui/number-translation';
import { DevUIModule } from 'ng-devui';
import { faStackOverflow, faGithub, faMedium } from '@fortawesome/free-brands-svg-icons';
import { FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { faSquare, faCheckSquare, faBars, faChevronDown } from '@fortawesome/free-solid-svg-icons';
import { IconModule } from 'ng-devui/icon';
import { TranslateModule } from '@ngx-translate/core';
import { I18nDatePipe, I18nModule } from 'ng-devui/i18n';
import { LazyLoadModule } from 'ng-devui/utils';
import { PageNotFoundComponent } from '@app/public/page-not-found/page-not-found.component';
import { GuaranteesComponent } from '@app/guarantees/profiles/guarantees.component';

import { PipesModule } from '@app/guarantees/shared/pipes/pipes.module';
import { NgModule } from '@angular/core';
import { GuaranteesRoutingModule } from '@app/guarantees/profiles/guarantees-routing.module';
import { AuthGuard } from '@src/app/core/services/auth-guard.service';
import { InternalEventService } from '@src/app/core/tools/internal-event.service';

@NgModule({
  declarations: [
    GuaranteesComponent,
    // PageNotFoundComponent,
  ],
  imports: [
    CommonModule,
    GuaranteesRoutingModule,
    // TranslateModule,
    // PipesModule,
    // DevUIModule,
    // I18nModule,
    // IconModule,
    // LazyLoadModule,
    // NumberTransModule,
    TranslateModule.forRoot()
  ],
  providers: [
    CommonModule,
    AuthGuard,
    // AesService,
    // JwtService,
    // LoggedUserService,
    InternalEventService,
    // RouterLink, FormBuilder, FormGroup,
    // UntypedFormControl, UntypedFormGroup, Validators,
    // AlertModule,
    // AuthStore,
    // AuthService,

    // StrategyProviders,
    // // UtilsProviders,
    // TranslateService,
    // // RegistrationsContractsDtService,
    // httpInterceptorProviders,
    // // PublicModule
  ],

  exports: [
    // I18nDatePipe,

    // TranslateModule,
    // PipesModule,
  ]

})
export class GuaranteesModule {
  constructor(library: FaIconLibrary) {
    library.addIcons(
      faSquare,
      faCheckSquare,
      faStackOverflow,
      faGithub,
      faMedium,
      faBars,
      faChevronDown
    );
  }

}
