import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from '@app/public/page-not-found/page-not-found.component';
import { AuthGuard } from '@app/core/services/auth-guard.service';
import { PublicRoutes } from '@src/app/public/public.routes';
import { GuaranteesRoutes } from '@app/guarantees/profiles/guarantees.routes';
import { ProfileAdminComponent } from '@app/guarantees/profiles/admin/profile-admin.component';

const routes: Routes = [
  {
    data: { roles: ['ROLE_ADMIN', 'user'] },
    path: GuaranteesRoutes.AdminProfile,   
    canActivate: [AuthGuard],
    component: ProfileAdminComponent,
    loadChildren: () => import('@app/guarantees/profiles/admin/profile-admin.module').then((m) => m.ProfileAdminModule), 
    // loadChildren: () => import('@app/guarantees/profiles/admin/layouts/layouts.module').then((m) => m.LayoutsModule),
    // children: [
    //   {
    //     path: GuaranteesRoutes.AdminProfile,
    //     component: ProfileAdminComponent,
    //     loadChildren: () => import('@app/guarantees/profiles/admin/profile-admin.module').then((m) => m.ProfileAdminModule),
    //   },
    // ],
  },
  // {
  //   path: GuaranteesRoutes.AdminProfile,
  //   component: ProfileAdminComponent,    
  //   loadChildren: () => import('@app/guarantees/profiles/admin/profile-admin.module').then((m) => m.ProfileAdminModule), 
  // },
  // {
  //   data: { roles: ['ROLE_ADMIN', 'user'] },
  //   title: 'Consulta de contratos',
  //   path: ProfileAdminRoutes.Contracts,   
  //   component: ContractsAdminComponent,
  //   canActivate: [AuthGuard],

  // },

  { 
    path: '**', 
    redirectTo: PublicRoutes.Home,
    component: PageNotFoundComponent,
    canActivate: [AuthGuard], 
  },
];

@NgModule({
  declarations: [],
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GuaranteesRoutingModule {}
