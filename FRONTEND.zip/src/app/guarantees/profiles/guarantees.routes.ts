export enum GuaranteesRoutes {
  Profile = 'profile',
  AdminProfile = 'admin',
}

export enum ProfileAdminRoutes {
  Dashboard = 'dashboard',
  Contracts = 'contracts'
}