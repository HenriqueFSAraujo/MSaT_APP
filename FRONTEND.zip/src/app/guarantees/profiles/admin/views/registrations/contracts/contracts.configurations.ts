import { TableWidthConfig } from "ng-devui";

export const tableWidthConfig: TableWidthConfig[] = [
    {
        field: 'checkbox',
        width: '41px'
    },
    {
        field: 'creditor',
        width: '120px'
    },
    {
        field: 'orderCreatedAt',
        width: '90px'
    },
    {
        field: 'contractNum',
        width: '80px'
    },
    {
        field: 'carPlate',
        width: '100px',
    },
    {
        field: 'carModel',
        width: '100px'
    },
    {
        field: 'currentStage',
        width: '130px'
    },
    {
        field: 'seizureStatus',
        width: '130px'
    },
    {
        field: 'lastMoveUpdatedAt',
        width: '130px'
    },
    {
        field: 'actions',
        width: '120px'
    },
];

export const dataTableOptions = {
    columns: [
        
        {
            field: 'creditor',
            header: 'Credor',
            fieldType: 'text',
            fixedLeft: '41px'
        },
        {
            field: 'orderCreatedAt',
            header: 'Data do Pedido',
            fieldType: 'date',
        },
        {
            field: 'contractNum',
            header: 'Contrato',
            fieldType: 'text'
        },
        {
            field: 'carPlate',
            header: 'Placa',
            fieldType: 'text',
            minWidth: '100px'
        },
        {
            field: 'carModel',
            header: 'Modelo',
            fieldType: 'text'
        },
        {
            field: 'currentStage',
            header: 'Etapa Atual',
            fieldType: 'text'
        },
        {
            field: 'seizureStatus',
            header: 'Status da Apreensão',
            fieldType: 'text'
        },
        {
            field: 'lastMoveUpdatedAt',
            header: 'Ultima Movimentação',
            fieldType: 'date'
        },
        // {
        //     field: 'actions',
        //     header: 'Ações',
        //     fieldType: 'text'
        // },
    ]
};

export const dataFilterOptions = 
    [ 
        {
            cardType: "filter",
            header: 'Filtro',
            breakPoints: {
                xxl: "12",
                xl: "12",
                lg: "12",
                md: "12",
                sm: "24",
                xs: "24",
            },
            fields: [
                
                {
                    field: 'orderCreatedAt',
                    fieldFrom: 'orderCreatedAtFrom',
                    fieldTo: 'orderCreatedAtTo',
                    header: 'Períodos',
                    fieldType: 'dateRangePicker',
                    helpTip: "",
                    rulesValidation: "",
                    maskInput: "",
                    icon: "",
                    initialValue: "",
                    eventEmit: "",
                    store: "",
                    storeField: "",
                    breakPoints: {
                        xxl: "12",
                        xl: "12",
                        lg: "12",
                        md: "12",
                        sm: "24",
                        xs: "24",
                    }
                    
                },
            
            ]
        }    
   ]
;




