import { NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';
import { NgModel } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DevUIModule } from 'ng-devui';
import { FormLayout } from 'ng-devui/form';
@Component({
  selector: 'd-modal-cases',
  templateUrl: './modal-cases.component.html',
  imports: [NgIf, DevUIModule, FontAwesomeModule],
  providers: [],
  standalone: true,
  styles: ['textarea { height: 100px; resize: none }'],
})
export class ModalCasesComponent {
  @Input() data: any;
  branch = 'develop';
  tagName = '';
  des = '';
  layoutDirection: FormLayout = FormLayout.Vertical;
 
  @Input() modalDetail: any;


  formChange() {
    if (this.branch && this.tagName) {
      this.data.canConfirm(true);
    } else {
      this.data.canConfirm(true);
    }
  }
}