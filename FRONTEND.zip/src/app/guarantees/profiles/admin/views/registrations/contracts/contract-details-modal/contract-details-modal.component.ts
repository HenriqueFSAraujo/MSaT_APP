import { ChangeDetectionStrategy, Component, inject, Input, OnInit, TemplateRef } from '@angular/core';
import { NgIf } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DevUIModule, TableWidthConfig } from 'ng-devui';
import { DialogService } from 'ng-devui/modal';
 
import { pageTransition } from '@app/shared/utils/animations';
import { ContractDetailModal } from '@src/app/guarantees/shared/models/contract-details-modal.model';
import { ContractDetailService } from '@src/app/guarantees/shared/services/contract-details-modal.service';
import { ModalCasesComponent } from './modal-cases.component';
// import { DataTableComponent } from '@app/guarantees/shared/components/data-table/data-table.component';
// import { dataTableOptions, tableWidthConfig, dataFilterOptions } from '@app/guarantees/profiles/admin/views/registrations/contracts/contracts.configurations';
//import { RegistrationsContractsDtService } from '@app/guarantees/shared/services/registrations-contracts-dt.service';
//import { RegistrationsContractsDtStore } from '@app/guarantees/shared/stores/registrations-contracts-dt.store';
// import { FilterTableComponent } from '@app/guarantees/shared/components/filter-table/filter-table.component';

@Component({
  selector: 'app-contracts-details-modal',
  templateUrl: './contract-details-modal2.html',
  styleUrls: ['./contract-details-modal.scss'],
  standalone: true,
  providers: [ContractDetailService],
  imports: [NgIf, DevUIModule, FontAwesomeModule, ModalCasesComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [pageTransition]
})
export class ContractAdminDetailsModalComponent implements OnInit {

  modalDatail: any = {};


  @Input() contractDetails: ContractDetailModal | undefined;
 
  contractDetail!: ContractDetailModal;

  constructor(private contractDetailService: ContractDetailService , private dialogService: DialogService) { }
  
  ngOnInit(): void {
    this.modalDatail = this.loadContractDetails();

  }

  loadContractDetails(): any {
    return this.contractDetailService.getContractDetails;
  }


    openStandardDialog(dialogtype: string , dataModal: any) {
      const results = this.dialogService.open({
        id: 'dialog-service',
        width: '600px',
        maxHeight: '600px',
       
        title: '新建标签',
        content: ModalCasesComponent,
        backdropCloseable: true,
        dialogtype: dialogtype,
        onClose: () => {
          console.log('on dialog closed');
        },
        buttons: [
          {
            cssClass: 'primary',
            text: '确定',
            disabled: true,
            handler: ($event: Event) => {
              console.log('tag created');
              results.modalInstance.hide();
            },
          },
          {
            id: 'btn-cancel',
            cssClass: 'common',
            text: '取消',
            handler: ($event: Event) => {
              results.modalInstance.hide();
            },
          },
        ],

        
        data: {
          dataModal: this.modalDatail,
          canConfirm: (value: boolean) => {
            results.modalInstance.updateButtonOptions([{disabled: !value}]);
          }
        },
      });
      console.log(results.modalContentInstance);
    }
}
