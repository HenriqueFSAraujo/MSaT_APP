import { Component, ElementRef, inject, Renderer2, ChangeDetectionStrategy, TemplateRef, Inject, ViewEncapsulation, computed } from '@angular/core';
import { AuthService } from '@app/core/auth/auth.service';
import { Images } from '@src/assets/data/images';
import { HeaderStore } from './header.store';
import { NgIf } from '@angular/common';
import { DevUIModule } from 'ng-devui';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SidebarStore } from '../sidebar/sidebar.store';

@Component({
  selector: 'app-header-profile-admin',
  standalone: true,
  templateUrl: './header-admin.component.html',
  styleUrls: ['./header-admin.component.css'],
  imports: [NgIf, DevUIModule, FontAwesomeModule, ],
  
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [HeaderStore, SidebarStore, ],
  // encapsulation: ViewEncapsulation.None
})
export class HeaderComponent {
  // protected readonly store = inject(HeaderStore);
  protected readonly sidebarStore = inject(SidebarStore);
  public userOne: string = Images.users.userOne;
  public show: boolean = this.store.$sidebarMenuOpen();
  public user: any = {}

  // public readonly show = computed<boolean>(() => {    
  //   return this.sidebarStore.$sidebarMenuOpen();
  // });



  public logoOne: string = Images.logo.logoOne;

  constructor(
    private element: ElementRef, private renderer: Renderer2,
    private authService: AuthService,
    @Inject(HeaderStore) public store: HeaderStore,
  ) {
    this.user = this.authService.getUser()


   }

  onClickLogout = () => {
    this.authService.logout()
  };

  onClickProfile = () => {
    const profileDropdownList = this.element.nativeElement.querySelector('.profile-dropdown-list');
    this.renderer.setAttribute(profileDropdownList, 'aria-expanded', 'true');
  };

  toggleButtonMenu(){    
    
    const isOpen = true;
    // const menuHeader = this.element.nativeElement.querySelector('.menu-header');
    // this.renderer.setAttribute(menuHeader, 'aria-expanded', 'false');
    this.store.setSidebarMenuOpen({isOpen});   
    this.sidebarStore.setSidebarMenuOpen({isOpen});    
  }
}
