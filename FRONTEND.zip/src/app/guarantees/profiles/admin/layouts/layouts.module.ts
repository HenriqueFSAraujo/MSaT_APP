import { CommonModule } from '@angular/common';
import { NgModule, TemplateRef } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
// import { HeaderComponent } from './header/header-admin.component';
import { SidebarCollapseDirective } from './sidebar/sidebar-collapse.directive';
import { SidebarComponent } from './sidebar/sidebar.component';
import { DataTableComponent, DevUIModule, DFormControlRuleDirective } from 'ng-devui';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DataTableService } from '@src/app/guarantees/shared/services/data-table.service';
import { AppDataTableContentDirective } from '@src/app/guarantees/shared/directives/DataTableDirective';
import { HeaderComponent } from './header/header-admin.component';


@NgModule({
  declarations: [
    // SidebarComponent,
    FooterComponent,
    // AppDataTableContentDirective
    
    // HeaderComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    SidebarCollapseDirective,
    DevUIModule,
    FontAwesomeModule,
    // AppDataTableContentDirective
    
  ],
  providers: [SidebarComponent],

  exports: [
    // HeaderComponent,
    CommonModule,
    
    // SidebarComponent,
    FooterComponent,
    // AppDataTableContentDirective
    DFormControlRuleDirective
  ]
})
export class LayoutsModule { }
