import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfileAdminRoutes } from '@app/guarantees/profiles/admin/profile-admin.routes';

// import { DashboardComponent } from '@app/guarantees/profiles/admin/views/dashboard/dashboard.component';

import { AuthGuard } from '@app/core/services/auth-guard.service';
import { PublicRoutes } from '@src/app/public/public.routes';
import { ContractsAdminComponent } from './views/registrations/contracts/contracts.component';
import { ProfileAdminDashboardComponent } from './views/dashboard/dashboard.component';
import { PageNotFoundComponent } from '@src/app/public/page-not-found/page-not-found.component';
import { ContractAdminDetailsModalComponent } from '@app/guarantees/profiles/admin/views/registrations/contracts/contract-details-modal/contract-details-modal.component';


const routes: Routes = [
  {
    data: { roles: ['ROLE_ADMIN', 'user'] },
    path: ProfileAdminRoutes.Dashboard,   
    canActivate: [AuthGuard],
    component: ProfileAdminDashboardComponent,
    loadChildren: () => import('@app/guarantees/profiles/admin/layouts/layouts.module').then((m) => m.LayoutsModule), 
  },
  {
    data: { roles: ['ROLE_ADMIN', 'user'] },
    path: ProfileAdminRoutes.Contracts,   
    canActivate: [AuthGuard],
    component: ContractsAdminComponent,
    loadChildren: () => import('@app/guarantees/profiles/admin/layouts/layouts.module').then((m) => m.LayoutsModule), 
  },
  {
    data: { roles: ['ROLE_ADMIN', 'user'] },
    path: ProfileAdminRoutes.Modal,   
    canActivate: [AuthGuard],
    component: ContractAdminDetailsModalComponent,
    loadChildren: () => import('@app/guarantees/profiles/admin/layouts/layouts.module').then((m) => m.LayoutsModule), 
  },

  
  // {
  //   data: { roles: ['ROLE_ADMIN', 'user'] },
  //   title: 'Consulta de contratos',
  //   path: ProfileAdminRoutes.Contracts,   
  //   component: ContractsAdminComponent,
  //   canActivate: [AuthGuard],

  // },

  { 
    path: '**', 
    redirectTo: PublicRoutes.Home,
    component: PageNotFoundComponent,
    canActivate: [AuthGuard], 
  },
];

@NgModule({
  declarations: [],
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfileAdminRoutingModule {}
