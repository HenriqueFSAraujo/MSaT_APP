/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */

/**
 * This file includes polyfills needed by Angular and is loaded before the app.
 * You can add your own extra polyfills to this file.
 *
 * This file is divided into 2 sections:
 *   1. Browser polyfills. These are applied before loading ZoneJS and are sorted by browsers.
 *   2. Application imports. Files imported after ZoneJS that should be loaded before your main
 *      file.
 *
 * The current setup is for so-called "evergreen" browsers; the last versions of browsers that
 * automatically update themselves. This includes Safari >= 10, Chrome >= 55 (including Opera),
 * Edge >= 13 on the desktop, and iOS 10 and Chrome on mobile.
 *
 * Learn more in https://angular.dev/reference/versions#browser-support
 */

/***************************************************************************************************
 * BROWSER POLYFILLS
 */

/**
 * Required to support Web Animations `@angular/platform-browser/animations`.
 * Needed for: All but Chrome, Firefox and Opera. http://caniuse.com/#feat=web-animation
 **/
// import 'web-animations-js';  // Run `npm install --save web-animations-js`.

/***************************************************************************************************
 * Zone JS is required by default for Angular itself.
 */
import 'zone.js'; // Included with Angular CLI.

// import 'zone.js/dist/zone';
import "core-js/proposals/reflect-metadata";



/***************************************************************************************************
 * APPLICATION IMPORTS
 */

// import * as process from 'process';

// import 'process'; 
// require.resolve("process")
let load: (<T>(modulePath: string | URL) => Promise<T>) | undefined;

export async function loadEsmModule<T>(modulePath: string | URL): Promise<T> {
    load ??= new Function('modulePath', `return import(modulePath);`) as Exclude<
      typeof load,
      undefined
    >;
  
    return await load(modulePath);
  }

  
  import yargs from 'yargs'
import { hideBin } from 'yargs/helpers'
//   const readFileSync: any =  import('fs')
  // const dotenv: any = loadEsmModule('dotenv')  
// import * as fs from 'fs';
// import * as  from 'typescript';
// const fs = require('yargs')
let targetPath = `./src/environments/environment.ts`;

// const env = fs.readFileSync(targetPath);

// const env = readFile(targetPath, function (err) {
//     if (err) {
//       console.log(err);
//     }
  
//     console.log(`Output generated at ${targetPath}`);
//   });

// const fl = readFile('./src/proxy.conf.json').then((value)=>{

// })


// const process = import("dotenv")
import * as process from 'process';
import { readFile } from 'fs/promises';

// import 'yargs';
// import { argv } from 'yargs';
console.log('process222', window['process']);


// yargs(hideBin([
//   '--environment=prod',
//   'secretKey=YXdUU1pMTjQ4R3pCMExRUGRjMTd5VGF1Q1FoYWZ6N1U='
// ]))
//   .command('curl <url>', 'fetch the contents of the URL', () => {}, (argv) => {
//     console.info(argv)
//   })
//   .demandCommand(1)
//   .parse()
// const envArg: any = argv;
// require('expose-gc');
// const gc = require('expose-gc/function');
// const process = require('process');
// const process = require('process');
window['process'] = {...process, env:{
  ...process.env,
  secretKey: '123',
  
  apiUrl: '',
  siteUrl: '',
  apiEndpoint: '',
  domainCookie: '',
  pathCookie: ''
}};

// global.gc();
console.log('process', window['process']);
// console.log('envArg', argv);

